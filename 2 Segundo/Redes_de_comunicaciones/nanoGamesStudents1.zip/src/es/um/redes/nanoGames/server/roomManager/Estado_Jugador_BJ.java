package es.um.redes.nanoGames.server.roomManager;

public enum Estado_Jugador_BJ {

	PLANTADO, SOBREPASA, JUGANDO, GANADOR;
	
}
