package vista;

import java.awt.Font;
import java.awt.event.ActionEvent;

import javax.swing.GroupLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;

import controlador.ControladorAppVideo;

@SuppressWarnings("serial")
public class VentanaLogin extends Ventana{
	
	private String nombreVentana;
	
	private JLabel labelUsuario;
	private JLabel labelPasswd;
	
	private JTextField usuario;
	
	private JPasswordField passwordField;
	
	private JButton btnAceptar;
	private JButton btnCancelar;

	public VentanaLogin(JFrame ventana, ControladorAppVideo controlador) {
		// Inicializamos la variable controlador
		this.controlador = controlador;
		// Inicializar las variables
		this.ventana = ventana;
		nombreVentana = "Iniciar sesi�n";
		// Inicializar el panel de la ventana actual
		initialize();
	}
	
	String getNombreVentana() {
		return nombreVentana;
	}
	
	/*
	 * Elementos visuales a�adidos a la clase padre Ventana
	 */
	void comportamientoParticular(JPanel panel_1){
		
		labelUsuario = new JLabel("Usuario");
		labelUsuario.setFont(new Font("Tahoma", Font.PLAIN, 15));
		
		labelPasswd = new JLabel("Contrase\u00F1a");
		labelPasswd.setFont(new Font("Tahoma", Font.PLAIN, 15));
		
		usuario = new JTextField();
		usuario.setColumns(10);
		
		passwordField = new JPasswordField();
		
		btnAceptar = new JButton("Aceptar");
		btnAceptar.addActionListener(this);
		
		btnCancelar = new JButton("Cancelar");
		btnCancelar.addActionListener(this);
		
		GroupLayout gl_panel_1 = new GroupLayout(panel_1);
		gl_panel_1.setHorizontalGroup(
			gl_panel_1.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel_1.createSequentialGroup()
						.addPreferredGap(ComponentPlacement.RELATED, 275, Short.MAX_VALUE)
					.addGroup(gl_panel_1.createParallelGroup(Alignment.TRAILING)
						.addComponent(labelUsuario)
						.addGroup(gl_panel_1.createParallelGroup(Alignment.LEADING)
							.addComponent(btnAceptar)
							.addComponent(labelPasswd)))
					.addGap(26)
					.addGroup(gl_panel_1.createParallelGroup(Alignment.TRAILING, false)
						.addComponent(passwordField)
						.addComponent(usuario)
						.addComponent(btnCancelar))
					.addContainerGap(286, Short.MAX_VALUE))
		);
		gl_panel_1.setVerticalGroup(
			gl_panel_1.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel_1.createSequentialGroup()
					.addPreferredGap(ComponentPlacement.RELATED, 50, Short.MAX_VALUE)
					.addGroup(gl_panel_1.createParallelGroup(Alignment.BASELINE)
						.addComponent(labelUsuario)
						.addComponent(usuario, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(18)
					.addGroup(gl_panel_1.createParallelGroup(Alignment.BASELINE)
						.addComponent(labelPasswd)
						.addComponent(passwordField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(58)
					.addPreferredGap(ComponentPlacement.RELATED, 15, Short.MAX_VALUE)
					.addGroup(gl_panel_1.createParallelGroup(Alignment.BASELINE)
						.addComponent(btnAceptar)
						.addComponent(btnCancelar))
					.addContainerGap(50, Short.MAX_VALUE))
		);
		panel_1.setLayout(gl_panel_1);
	}
	
	void accionesVentanas(ActionEvent e) {
		if (e.getSource() == btnAceptar) { 
			// Se intenta loguear al usuario
			if (loginUsuario()) {
				// Se muestra un di�logo al usuario cuando se ha iniciado sesi�n
				JOptionPane.showMessageDialog(ventana, "Sesi�n iniciada correctamente", "Datos correctos", JOptionPane.INFORMATION_MESSAGE);
				// Obtenemos si es un usuario Premium o est�ndar
				if (isPremium())
					// Y si es premium, queremos saber si es su cumplea�os
					if (isCumplea�os())
						JOptionPane.showMessageDialog(ventana, "�Feliz Cumplea�os!", "Hoy es un d�a especial...", JOptionPane.INFORMATION_MESSAGE);
				// Finalmente se muestra la ventana de V�deos recientes
				Inicio.setVentanaRecientes();
			} else
				// Si el usuario no ha podido loguearse se muestra una ventana de error
				JOptionPane.showMessageDialog(ventana, "Usuario o contrase�a incorrectos", "Error al iniciar sesi�n", JOptionPane.ERROR_MESSAGE);
		} else if (e.getSource() == btnCancelar) { 
			// Volver a la pantalla de inicio
			Inicio.setVentanaPrincipal();
		}
	}
	
	/*
	 * Funci�n para limpiar los campos de login
	 */
	public void limpiar() {
		usuario.setText("");
		passwordField.setText("");
	}
	
	/*
	 * Funci�n que comprueba que obtiene el nombre de usuario y contrase�a del login, y solicita iniciar sesi�n al controlador
	 */
	private boolean loginUsuario() {
		String auxUsuario = usuario.getText().trim();
		char auxPasswdArray[] = passwordField.getPassword();
		if (controlador.loginUsuario(auxUsuario, auxPasswdArray)) {
			// Indicamos en la clase Inicio que el usuario ha iniciado sesi�n
			Inicio.setSesionIniciada();
			Inicio.setNombreUsuario(controlador.getNombreUsuario());
			Inicio.construirVentanas();
			return true;
		}
		return false;
	}
	
	/*
	 * Preguntar si el usuario que ha iniciado sesi�n es premium
	 */
	private boolean isPremium() {
		if (controlador.isPremium() > 0) {
			Inicio.setUsuarioPremium();
			return true;
		}
		return false;
	}
	
	/*
	 * Preguntar si hoy es el cumplea�os del usuario
	 */
	private boolean isCumplea�os() {
		if (controlador.isCumplea�os() > 0)
			return true;
		return false;
	}
}
