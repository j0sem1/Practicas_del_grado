package vista;

import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;

import javax.swing.GroupLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.UIManager;
import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;

import controlador.ControladorAppVideo;

@SuppressWarnings("serial")
public class VentanaNuevaLista extends Ventana implements MouseListener {
	
	private String nombreVentana;
	
	private JLabel labelNombreLista;
	private JLabel labelNombreVideo;
	
	private JTextField fieldNombreLista;
	private JTextField fieldNombreVideo;
	
	private JButton btnAceptar;
	private JButton btnA�adir;
	private JButton btnBorrar;
	private JButton btnEliminar;
	private JButton btnBuscarLista;
	private JButton btnNuevaBusq;
	private JButton btnBuscarVideos;
	
	private JPanel panelBusqLista;
	private JScrollPane scrollPaneMiniaturasLista;
	private JPanel panelMiniaturasLista;
	private JPanel panelBtnAceptar;
	private JPanel panelVideos;
	private JPanel panelMiniaturasVideos;
	
	private JPanel panelAnterior;
	
	private boolean listaSeleccionada;

	
	public VentanaNuevaLista(JFrame ventana, ControladorAppVideo controlador) {
		// Inicializamos la variable controlador
		this.controlador = controlador;
		// Inicializar las variables
		this.ventana = ventana;
		nombreVentana = "A�adir nueva lista o Modificar una existente";
		panelAnterior = null;
		listaSeleccionada = false;
		// Inicializar el panel de la ventana actual
		initialize();
	}
	
	String getNombreVentana() {
		return nombreVentana;
	}
	
	/*
	 * Elementos visuales a�adidos a la clase padre Ventana
	 */
	void comportamientoParticular(JPanel panel_1){
		
		// Inicializaci�n de los JPanel y JScrollPane
		panelVideos = new JPanel();
		panelBusqLista = new JPanel();
		panelBtnAceptar = new JPanel();
		scrollPaneMiniaturasLista = new JScrollPane();
		panelMiniaturasLista = new JPanel();
		panelMiniaturasVideos = new JPanel();
		
		GroupLayout gl_panel_1 = new GroupLayout(panel_1);
		gl_panel_1.setHorizontalGroup(
				gl_panel_1.createParallelGroup(Alignment.TRAILING)
					.addGroup(gl_panel_1.createSequentialGroup()
						.addGroup(gl_panel_1.createParallelGroup(Alignment.LEADING)
							.addComponent(scrollPaneMiniaturasLista, GroupLayout.PREFERRED_SIZE, 208, GroupLayout.PREFERRED_SIZE)
							.addComponent(panelBtnAceptar, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
							.addComponent(panelBusqLista, Alignment.TRAILING, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
						.addGap(7)
						.addComponent(panelVideos, GroupLayout.DEFAULT_SIZE, 555, Short.MAX_VALUE)
						.addGap(10))
			);
		gl_panel_1.setVerticalGroup(
			gl_panel_1.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel_1.createSequentialGroup()
					.addComponent(panelBusqLista, GroupLayout.PREFERRED_SIZE, 89, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(scrollPaneMiniaturasLista, GroupLayout.DEFAULT_SIZE, 220, Short.MAX_VALUE)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(panelBtnAceptar, GroupLayout.PREFERRED_SIZE, 77, GroupLayout.PREFERRED_SIZE)
					.addContainerGap())
				.addComponent(panelVideos, GroupLayout.DEFAULT_SIZE, 413, Short.MAX_VALUE)
		);
		
		scrollPaneMiniaturasLista.setViewportView(panelMiniaturasLista);
		panelMiniaturasLista.setSize(new Dimension(Constantes.width_panelMiniaturasVideos, Constantes.height_panelMiniaturasVideos));
		panelMiniaturasLista.setLayout(new WrapLayout());
		
		btnAceptar = new JButton("Aceptar");
		btnAceptar.addActionListener(this);
		
		btnA�adir = new JButton("A\u00F1adir");
		btnA�adir.addActionListener(this);
		
		btnBorrar = new JButton("Borrar");
		btnBorrar.addActionListener(this);
		
		GroupLayout gl_panel_4 = new GroupLayout(panelBtnAceptar);
		gl_panel_4.setHorizontalGroup(
				gl_panel_4.createParallelGroup(Alignment.LEADING)
					.addGroup(gl_panel_4.createSequentialGroup()
						.addGroup(gl_panel_4.createParallelGroup(Alignment.LEADING)
							.addGroup(gl_panel_4.createSequentialGroup()
								.addGap(65)
								.addComponent(btnAceptar)
								.addPreferredGap(ComponentPlacement.RELATED, 54, Short.MAX_VALUE))
							.addGroup(gl_panel_4.createSequentialGroup()
								.addContainerGap()
								.addComponent(btnA�adir, GroupLayout.PREFERRED_SIZE, 78, GroupLayout.PREFERRED_SIZE)
								.addGap(29)
								.addComponent(btnBorrar, GroupLayout.PREFERRED_SIZE, 77, GroupLayout.PREFERRED_SIZE)
								.addGap(0, 0, Short.MAX_VALUE)))
						.addContainerGap())
			);
		gl_panel_4.setVerticalGroup(
				gl_panel_4.createParallelGroup(Alignment.TRAILING)
					.addGroup(gl_panel_4.createSequentialGroup()
						.addContainerGap()
						.addGroup(gl_panel_4.createParallelGroup(Alignment.BASELINE)
							.addComponent(btnA�adir)
							.addComponent(btnBorrar))
						.addPreferredGap(ComponentPlacement.RELATED, 14, Short.MAX_VALUE)
						.addComponent(btnAceptar))
			);
		
		panelBtnAceptar.setLayout(gl_panel_4);
		
		labelNombreLista = new JLabel("Introducir nombre lista");
		
		fieldNombreLista = new JTextField();
		fieldNombreLista.setColumns(10);
		
		btnBuscarLista = new JButton("Buscar");
		btnBuscarLista.addActionListener(this);
		
		btnEliminar = new JButton("Eliminar");
		btnEliminar.addActionListener(this);
		GroupLayout gl_panel_3 = new GroupLayout(panelBusqLista);
		gl_panel_3.setHorizontalGroup(
				gl_panel_3.createParallelGroup(Alignment.LEADING)
					.addGroup(gl_panel_3.createSequentialGroup()
						.addGroup(gl_panel_3.createParallelGroup(Alignment.LEADING)
							.addGroup(gl_panel_3.createSequentialGroup()
								.addGap(12)
								.addComponent(fieldNombreLista, GroupLayout.PREFERRED_SIZE, 184, GroupLayout.PREFERRED_SIZE)
								.addGap(0, 0, Short.MAX_VALUE))
							.addGroup(gl_panel_3.createSequentialGroup()
								.addContainerGap()
								.addComponent(btnBuscarLista, GroupLayout.PREFERRED_SIZE, 80, GroupLayout.PREFERRED_SIZE)
								.addGap(18)
								.addComponent(btnEliminar, GroupLayout.PREFERRED_SIZE, 86, GroupLayout.PREFERRED_SIZE)
								.addGap(0, 0, Short.MAX_VALUE))
							.addGroup(gl_panel_3.createSequentialGroup()
								.addContainerGap()
								.addComponent(labelNombreLista)))
						.addContainerGap())
			);
		gl_panel_3.setVerticalGroup(
			gl_panel_3.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel_3.createSequentialGroup()
					.addComponent(labelNombreLista)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(fieldNombreLista, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addGroup(gl_panel_3.createParallelGroup(Alignment.BASELINE)
						.addComponent(btnBuscarLista)
						.addComponent(btnEliminar))
					.addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
		);
		
		panelBusqLista.setLayout(gl_panel_3);
		
		btnNuevaBusq = new JButton("Nueva b\u00FAsqueda");
		btnNuevaBusq.addActionListener(this);
		
		btnBuscarVideos = new JButton("Buscar");
		btnBuscarVideos.addActionListener(this);
		
		fieldNombreVideo = new JTextField();
		fieldNombreVideo.setColumns(10);
		
		labelNombreVideo = new JLabel("Buscar t\u00EDtulo");
		
		JScrollPane scrollPane = new JScrollPane();
		GroupLayout gl_panel_2 = new GroupLayout(panelVideos);
		gl_panel_2.setHorizontalGroup(
				gl_panel_2.createParallelGroup(Alignment.LEADING)
					.addGroup(gl_panel_2.createSequentialGroup()
						.addContainerGap()
						.addGroup(gl_panel_2.createParallelGroup(Alignment.TRAILING, false)
							.addGroup(gl_panel_2.createSequentialGroup()
								.addComponent(labelNombreVideo)
								.addPreferredGap(ComponentPlacement.UNRELATED)
								.addComponent(fieldNombreVideo, GroupLayout.PREFERRED_SIZE, 360, GroupLayout.PREFERRED_SIZE)
								.addPreferredGap(ComponentPlacement.RELATED, 18, Short.MAX_VALUE)
								.addComponent(btnBuscarVideos)
								.addContainerGap())
							.addGroup(gl_panel_2.createSequentialGroup()
								.addComponent(btnNuevaBusq)
								.addGap(205))))
					.addComponent(scrollPane, Alignment.TRAILING, GroupLayout.PREFERRED_SIZE, 555, GroupLayout.PREFERRED_SIZE)
			);
		gl_panel_2.setVerticalGroup(
			gl_panel_2.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel_2.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_panel_2.createParallelGroup(Alignment.BASELINE)
						.addComponent(labelNombreVideo)
						.addComponent(fieldNombreVideo, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(btnBuscarVideos))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(btnNuevaBusq)
					.addGap(18)
					.addComponent(scrollPane, GroupLayout.DEFAULT_SIZE, 312, Short.MAX_VALUE)
					.addContainerGap())
		);
		
		panelVideos.setLayout(gl_panel_2);
	    
		panel_1.setLayout(gl_panel_1);
		
		scrollPane.setViewportView(panelMiniaturasVideos);
		panelMiniaturasVideos.setSize(new Dimension(Constantes.width_panelMiniaturasVideos, Constantes.height_panelMiniaturasVideos));
		panelMiniaturasVideos.setLayout(new WrapLayout());
	}
	
	void accionesVentanas(ActionEvent e) {
		if (e.getSource() == btnEliminar) {
			// Eliminar la lista seleccionada
			eliminarLista();
		} else if (e.getSource() == btnBorrar) {
			// Eliminar el v�deo seleccionado de la lista que se est� editando
			// Si se ha seleccionado un v�deo
			// Se comprueba que el v�deo seleccionado es de la lista, no de los v�deos mostrados a la derecha
			if ((panelAnterior != null) && (panelAnterior.getParent().equals(panelMiniaturasLista))) {
				// Se obtiene su c�digo
				int codigoVideo = Integer.valueOf(((JLabel) panelAnterior.getComponent(1)).getText());
				// Se ordena la eliminaci�n de la lista del v�deo con dicho c�digo asignado
				eliminarVideo(codigoVideo);
				// Eliminar el v�deo de la interfaz
				panelMiniaturasLista.remove(panelAnterior);
				panelAnterior = null;
				ventana.revalidate(); /*redibujar con el nuevo JPanel*/
				ventana.repaint();
			}
		} else if (e.getSource() == btnA�adir) {
			// A�adir el v�deo seleccionado a la lista que se est� editando
			if (panelAnterior != null) {
				// Se obtiene la url que se ha guardado en la funci�n 'a�adirMiniatura()'
				String urlVideo = ((JLabel) panelAnterior.getComponent(0)).getText();
				// Se obtiene el c�digo
				int codigoVideo = Integer.valueOf(((JLabel) panelAnterior.getComponent(1)).getText());
				// A partir del c�digo volvemos a obtener el c�digo del v�deo
				String tituloVideo = controlador.getTituloVideo(codigoVideo);
				// Y finalmente lo a�adimos a la lista
				if (a�adirVideo(codigoVideo)) {
					// Y a la interfaz
					a�adirMiniaturaLista(this, panelMiniaturasLista, urlVideo, tituloVideo, codigoVideo);
					ventana.revalidate(); /*redibujar con el nuevo JPanel*/
					ventana.repaint();
				}
			}
		} else if (e.getSource() == btnAceptar) {
			// Guardar cambios (si se han producido) e ir a la Ventana Mis Listas
			guardarLista();
			Inicio.setVentanaMisListas();
		} else if (e.getSource() == btnNuevaBusq) {
			// Limpiar el campo de b�squeda por t�tulo de v�deos y la lista de v�deos encontrados
			limpiar();
			panelMiniaturasVideos.removeAll();
			ventana.revalidate(); /*redibujar con el nuevo JPanel*/
			ventana.repaint();
		} else if (e.getSource() == btnBuscarVideos) {
			// Buscar v�deos
			realizarBusquedaSinEtiquetas();
		} else if (e.getSource() == btnBuscarLista) {
			// Buscar lista. Si no se encuentra ninguna con ese nombre se abre una ventana
			if (!realizarBusquedaLista()) {
				int respuesta = JOptionPane.showConfirmDialog(ventana, "No se ha encontrado ninguna lista, �desea crear una nueva?", "Lista no encontrada", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
					if (respuesta == JOptionPane.YES_OPTION) {
						// Crear lista
						crearLista();
						Inicio.setEditandoLista(true);
						// Ahora se puede editar la lista creada
					} else {
						Inicio.setEditandoLista(false);
					}	
			} else {
				Inicio.setEditandoLista(true);
				// Ahora se puede editar la lista encontrada 
			}
			
			
		}
	}
	
	@Override
	public void mouseClicked(MouseEvent e) {
		// Si se ha pulsado un v�deo
		if (e.getSource().getClass() == JPanel.class) {
			// Obtenemos el panel que ha sido pulsado
			JPanel panelPulsado = (JPanel) e.getSource();
			// Si ya hab�a un v�deo seleccionado
			if (panelAnterior != null) {
				// y es distinto al que se ha seleccionado ahora
				if (panelAnterior != panelPulsado) {
					// Se cambia el fondo del v�deo seleccionado para que aparezca como tal
					// y se deja el fondo original para el v�deo que estaba ya seleccionado
					panelAnterior.setBackground(panelAnterior.getParent().getBackground());
					panelPulsado.setBackground(UIManager.getColor("activeCaption"));
				}
			} else
				// Si no hab�a un panel seleccionado solamente hay que cambiar el color
				// del panel pulsado
				panelPulsado.setBackground(UIManager.getColor("activeCaption"));
			// Ahora el panelAnterior pasar� a ser el que se acaba de pulsar
			panelAnterior = panelPulsado;
		}
	}
	
	/*
	 * Se solicita al controlador que busque entre las listas del usuario si se encuentra
	 * alguna con el nombre pasado como par�metro
	 */
	private boolean realizarBusquedaLista() {
		// Si no se ha introducido ning�n nombre no se produce la b�squeda
		if (fieldNombreLista.getText().equals(""))
			// Se devuelve true para que no aparezca la ventana de "Lista no enconcontrada"
			return true;
		// Realizamos la b�squeda y obtenemos un HashMap con la url y el c�digo del v�deo
		HashMap<String, String> videos = controlador.realizarBusquedaLista(fieldNombreLista.getText());
		
		if (videos != null) {
			// Creamos un iterador
			Iterator<Entry<String, String>> it = videos.entrySet().iterator();
					
			// Vamos recorriendo el mapa, obteniendo el t�tulo de cada v�deo, y a�adiendo la miniatura a la interfaz
			while (it.hasNext()) {
				HashMap.Entry<String, String> video = (HashMap.Entry<String, String>) it.next();
				int codigo = Integer.valueOf(video.getKey());
				a�adirMiniaturaLista(this, panelMiniaturasLista, video.getValue(), controlador.getTituloVideo(codigo), codigo);
			}
			
			ventana.revalidate(); /*redibujar con el nuevo JPanel*/
			ventana.repaint();
			listaSeleccionada = true;
			return true;
		}
		
		return false;
	}
	
	/*
	 * Ordena al controlador la creaci�n de una lista con el nombre pasado como par�metro
	 */
	private void crearLista() {
		controlador.crearLista(fieldNombreLista.getText());
		listaSeleccionada = true;
	}
	
	/*
	 * Se solicita al contralador que busque todos los v�deos del sistema que su t�tulo sea igual o contenga
	 * alguna palabra de la que ha escrito el usuario, aplicando adem�s el filtro del mismo
	 */
	private void realizarBusquedaSinEtiquetas() {
		// Limpiar el panel
		panelMiniaturasVideos.removeAll();
		
		// Realizamos la b�squeda y obtenemos un HashMap con la url y el c�digo del v�deo
		HashMap<String, String> videos = controlador.realizarBusquedaSinEtiquetas(fieldNombreVideo.getText());
				
		// Creamos un iterador
		Iterator<Entry<String, String>> it = videos.entrySet().iterator();
				
		// Vamos recorriendo el mapa, obteniendo el t�tulo de cada v�deo, y a�adiendo la miniatura a la interfaz
		while (it.hasNext()) {
			HashMap.Entry<String, String> video = (HashMap.Entry<String, String>) it.next();
			int codigo = Integer.valueOf(video.getKey());
			a�adirMiniaturaVideos(this, panelMiniaturasVideos, video.getValue(), controlador.getTituloVideo(codigo), codigo);
		}
		
		ventana.revalidate(); /*redibujar con el nuevo JPanel*/
		ventana.repaint();
	}
	
	/*
	 * Se guardan todos los cambios realizados en la lista
	 */
	private void guardarLista() {
		if (listaSeleccionada)
			controlador.guardarCambios();
		listaSeleccionada = false;
		Inicio.setEditandoLista(false);
	}
	
	/*
	 * Se limpia la barra donde se ha introducido el nombre del v�deo/s a buscar
	 */
	private void limpiar() {
		fieldNombreVideo.setText(null);
	}
	
	/*
	 * Se elimina la lista actual y se limpian los campos
	 */
	private void eliminarLista() {
		if (listaSeleccionada) {
			controlador.eliminarLista();
			limpiar();
		}
	}
	
	/*
	 * Eliminar el v�deo seleccionado de la lista actual
	 */
	private void eliminarVideo(int codigoVideo) {
		if (listaSeleccionada)
			controlador.eliminarVideoLista(codigoVideo);
	}
	
	/*
	 * A�adir el v�deo seleccionado a la lista actual. Devuelve true si el v�deo ha
	 * sido a�adido, y false si el v�deo seleccionado ya se encontraba en la lista o
	 * no se hab�a seleccionado ninguna lista
	 */
	private boolean a�adirVideo(int codigoVideo) {
		if (listaSeleccionada)
			return controlador.a�adirVideoLista(codigoVideo);
		return false;
	}

	
	// M�todos por defecto de la interfaz MouseListener
	
	@Override
	public void mouseEntered(MouseEvent arg0) {
		// Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent arg0) {
		// Auto-generated method stub
		
	}

	@Override
	public void mousePressed(MouseEvent arg0) {
		// Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent arg0) {
		// Auto-generated method stub
		
	}
	
}
