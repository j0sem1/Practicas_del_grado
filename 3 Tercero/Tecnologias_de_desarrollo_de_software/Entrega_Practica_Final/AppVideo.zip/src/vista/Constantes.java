package vista;

public class Constantes {
	public static final int ventana_x_size = 800;
	public static final int ventana_y_size = 600;
	public static final int nVideosxLinea_miniaturaVideo = 4;
	public static final int height_miniaturaVideo = 70;
	public static final int nVideosxLinea_miniaturaLista = 1;
	public static final int height_miniaturaLista = 110;
	public static final int width_panelMiniaturasVideos = 550;
	public static final int height_panelMiniaturasVideos = 180;
	public static final int size_panelMiniaturasList = 180;
}
