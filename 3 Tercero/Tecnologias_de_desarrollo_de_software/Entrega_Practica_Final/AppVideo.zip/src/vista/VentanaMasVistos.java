package vista;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.LinkedList;

import javax.swing.GroupLayout;
import javax.swing.JButton;
import javax.swing.JFormattedTextField;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.UIManager;
import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;

import controlador.ControladorAppVideo;

@SuppressWarnings("serial")
public class VentanaMasVistos extends Ventana implements MouseListener {
	
	private String nombreVentana;
	private String urlVideoActual;
	
	private JLabel labelTituloVideo;
	private JLabel labelNuevaEtiq;
	private JLabel labelNVisualiz;
	private JLabel labelNumero;
	
	private JTextField fieldNuevaEtiq;
	
	private JButton btnA�adirEtiq;
	private JButton btnCancelar;
	private JButton btnMasVistos;
	private JButton btnReproducir;
	
	private JPanel panelBtnReproducir;
	private JScrollPane scrollPaneMiniaturasVideos;
	private JPanel panelMiniaturasLista;
	private JPanel panelBtnCancelar;
	private JPanel panelReproduccion;
	private JPanel panelVideo;
	private JScrollPane scrollPaneEtiq;
	private JPanel panelEtiq;
	private JPanel panelAnterior;
	
	private int codigoVideo;

	public VentanaMasVistos(JFrame ventana, ControladorAppVideo controlador) {
		// Inicializamos la variable controlador
		this.controlador = controlador;
		// Inicializar las variables
		this.ventana = ventana;
		nombreVentana = "V�deos m�s vistos";
		// Inicializar el panel de la ventana actual
		initialize();
	}
	
	String getNombreVentana() {
		return nombreVentana;
	}
	
	/*
	 * Elementos visuales a�adidos a la clase padre Ventana
	 */
	void comportamientoParticular(JPanel panel_1){
		
		btnMasVistos = new JButton("M\u00E1s vistos");
		btnMasVistos.setForeground(Color.WHITE);
		btnMasVistos.setBackground(Color.RED);
		GridBagConstraints gbc_btnMsVistos = new GridBagConstraints();
		gbc_btnMsVistos.insets = new Insets(0, 0, 5, 5);
		gbc_btnMsVistos.gridx = 9;
		gbc_btnMsVistos.gridy = 1;
		
		// Se a�ade el bot�n para acceder a los v�deos m�s vistos si el usuario es premium
		if (Inicio.isUsuarioPremium())
			panel_1.getParent().add(btnMasVistos, gbc_btnMsVistos);
		
		panelReproduccion = new JPanel();
		panelReproduccion.setBackground(Color.LIGHT_GRAY);
		panelReproduccion.setVisible(false);
		
		panelBtnReproducir = new JPanel();
		
		panelBtnCancelar = new JPanel();
		
		panelVideo = new JPanel();
		
		scrollPaneEtiq = new JScrollPane();
		
		scrollPaneMiniaturasVideos = new JScrollPane();
		
		panelEtiq = new JPanel();
		
		GroupLayout gl_panel_1 = new GroupLayout(panel_1);
		gl_panel_1.setHorizontalGroup(
				gl_panel_1.createParallelGroup(Alignment.LEADING)
					.addGroup(gl_panel_1.createSequentialGroup()
						.addGroup(gl_panel_1.createParallelGroup(Alignment.LEADING, false)
							.addComponent(panelBtnCancelar, 0, 0, Short.MAX_VALUE)
							.addComponent(panelBtnReproducir, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
							.addComponent(scrollPaneMiniaturasVideos, GroupLayout.DEFAULT_SIZE, 206, Short.MAX_VALUE))
						.addPreferredGap(ComponentPlacement.RELATED)
						.addComponent(panelReproduccion, GroupLayout.PREFERRED_SIZE, 569, Short.MAX_VALUE)
						.addGap(16))
		);
		gl_panel_1.setVerticalGroup(
			gl_panel_1.createParallelGroup(Alignment.TRAILING)
				.addGroup(gl_panel_1.createSequentialGroup()
					.addGroup(gl_panel_1.createParallelGroup(Alignment.TRAILING)
						.addComponent(panelReproduccion, GroupLayout.DEFAULT_SIZE, 400, Short.MAX_VALUE)
						.addGroup(gl_panel_1.createSequentialGroup()
							.addComponent(panelBtnReproducir, GroupLayout.PREFERRED_SIZE, 25, GroupLayout.PREFERRED_SIZE)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(scrollPaneMiniaturasVideos, GroupLayout.DEFAULT_SIZE, 335, Short.MAX_VALUE)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(panelBtnCancelar, GroupLayout.PREFERRED_SIZE, 26, GroupLayout.PREFERRED_SIZE)))
					.addContainerGap())
		);
		
		panelMiniaturasLista = new JPanel();
		scrollPaneMiniaturasVideos.setViewportView(panelMiniaturasLista);
		panelMiniaturasLista.setSize(new Dimension(Constantes.size_panelMiniaturasList, Constantes.size_panelMiniaturasList));
		panelMiniaturasLista.setLayout(new WrapLayout());
		
		labelTituloVideo = new JLabel("T\u00EDtulo del v\u00EDdeo");
		labelTituloVideo.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 26));
		labelTituloVideo.setHorizontalAlignment(SwingConstants.CENTER);
		
		labelNuevaEtiq = new JLabel("Nueva etiqueta");
		
		fieldNuevaEtiq = new JTextField();
		fieldNuevaEtiq.setColumns(10);
		
		btnA�adirEtiq = new JButton("A\u00F1adir");
		btnA�adirEtiq.addActionListener(this);
		
		labelNVisualiz = new JLabel("N\u00FAmero de visualizaciones:");
		labelNVisualiz.setHorizontalAlignment(SwingConstants.RIGHT);
		
		labelNumero = new JLabel();
		labelNumero.setHorizontalAlignment(SwingConstants.LEFT);
		
		GroupLayout gl_panel_2 = new GroupLayout(panelReproduccion);
		gl_panel_2.setHorizontalGroup(
				gl_panel_2.createParallelGroup(Alignment.TRAILING)
					.addGroup(gl_panel_2.createSequentialGroup()
						.addContainerGap()
						.addGroup(gl_panel_2.createParallelGroup(Alignment.LEADING)
							.addComponent(scrollPaneEtiq, GroupLayout.DEFAULT_SIZE, 545, Short.MAX_VALUE)
							.addGroup(gl_panel_2.createSequentialGroup()
								.addComponent(labelNuevaEtiq)
								.addGap(26)
								.addComponent(fieldNuevaEtiq, GroupLayout.PREFERRED_SIZE, 318, GroupLayout.PREFERRED_SIZE)
								.addPreferredGap(ComponentPlacement.RELATED, 47, Short.MAX_VALUE)
								.addComponent(btnA�adirEtiq))
							.addComponent(labelTituloVideo, GroupLayout.DEFAULT_SIZE, 545, Short.MAX_VALUE)
							.addComponent(panelVideo, GroupLayout.DEFAULT_SIZE, 545, Short.MAX_VALUE)
							.addGroup(gl_panel_2.createSequentialGroup()
								.addComponent(labelNVisualiz, GroupLayout.DEFAULT_SIZE, 300, Short.MAX_VALUE)
								.addGap(18)
								.addComponent(labelNumero, GroupLayout.DEFAULT_SIZE, 227, Short.MAX_VALUE)))
						.addContainerGap())
			);
		gl_panel_2.setVerticalGroup(
			gl_panel_2.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel_2.createSequentialGroup()
					.addContainerGap()
					.addComponent(labelTituloVideo)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(panelVideo, GroupLayout.PREFERRED_SIZE, 230, GroupLayout.PREFERRED_SIZE)
					.addGap(18)
					.addComponent(scrollPaneEtiq, GroupLayout.PREFERRED_SIZE, 44, GroupLayout.PREFERRED_SIZE)
					.addGap(18)
					.addGroup(gl_panel_2.createParallelGroup(Alignment.BASELINE)
						.addComponent(labelNVisualiz)
						.addComponent(labelNumero))
					.addGap(18, 18, Short.MAX_VALUE)
					.addGroup(gl_panel_2.createParallelGroup(Alignment.BASELINE)
						.addComponent(labelNuevaEtiq)
						.addComponent(fieldNuevaEtiq, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(btnA�adirEtiq))
					.addContainerGap())
		);
		
		scrollPaneEtiq.setViewportView(panelEtiq);
		panelReproduccion.setLayout(gl_panel_2);
		
		btnCancelar = new JButton("Cancelar");
		btnCancelar.addActionListener(this);
		GroupLayout gl_panel_4 = new GroupLayout(panelBtnCancelar);
		gl_panel_4.setHorizontalGroup(
			gl_panel_4.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel_4.createSequentialGroup()
					.addGap(62)
					.addComponent(btnCancelar)
					.addContainerGap(63, Short.MAX_VALUE))
		);
		gl_panel_4.setVerticalGroup(
			gl_panel_4.createParallelGroup(Alignment.TRAILING)
				.addGroup(Alignment.LEADING, gl_panel_4.createSequentialGroup()
					.addComponent(btnCancelar)
					.addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
		);
		panelBtnCancelar.setLayout(gl_panel_4);
		
		btnReproducir = new JButton("Reproducir");
		btnReproducir.addActionListener(this);
		
		GroupLayout gl_panel_3 = new GroupLayout(panelBtnReproducir);
		gl_panel_3.setHorizontalGroup(
			gl_panel_3.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel_3.createSequentialGroup()
					.addGap(49)
					.addComponent(btnReproducir, GroupLayout.PREFERRED_SIZE, 104, GroupLayout.PREFERRED_SIZE)
					.addContainerGap(53, Short.MAX_VALUE))
		);
		gl_panel_3.setVerticalGroup(
			gl_panel_3.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel_3.createSequentialGroup()
					.addComponent(btnReproducir)
					.addContainerGap(64, Short.MAX_VALUE))
		);
		panelBtnReproducir.setLayout(gl_panel_3);
		
		panel_1.setLayout(gl_panel_1);
		
		panelVideo.add(Inicio.getVideoWeb());
		
		obtenerTopTen();
	}
	
	void accionesVentanas(ActionEvent e) {
		if (e.getSource() == btnCancelar) { 
			// Se vuelve a la p�gina de MisListas pero sin nada
			Inicio.setVentanaMasVistos();
		} else if (e.getSource() == btnA�adirEtiq) {
			a�adirEtiqueta(panelEtiq, fieldNuevaEtiq.getText(), urlVideoActual, codigoVideo);
			fieldNuevaEtiq.setText(null);
		} else if (e.getSource() == btnReproducir) {
			// Hay que reproducir el v�deo y obtener las etiquetas y el n�mero de reproducciones
			// Al reproducir el v�deo hay que ponerlo el primero en la lista de v�deos recientes del usuario
			reproducir();
		}
	}
	
	@Override
	public void mouseClicked(MouseEvent e) {
		// Si se ha pulsado un v�deo
		if (e.getSource().getClass() == JPanel.class) {
			// Obtenemos el panel que ha sido pulsado
			JPanel panelPulsado = (JPanel) e.getSource();
			// Si ya hab�a un v�deo seleccionado
			if (panelAnterior != null) {
				// y es distinto al que se ha seleccionado ahora
				if (panelAnterior != panelPulsado) {
					// Se cambia el fondo del v�deo seleccionado para que aparezca como tal
					// y se deja el fondo original para el v�deo que estaba ya seleccionado
					panelAnterior.setBackground(panelAnterior.getParent().getBackground());
					panelPulsado.setBackground(UIManager.getColor("activeCaption"));
				}
			} else
				panelPulsado.setBackground(UIManager.getColor("activeCaption"));
			panelAnterior = panelPulsado;
		}
	}
	
	/*
	 * Reproducir el video seleccionado
	 */
	private void reproducir() {
		if (panelAnterior != null) {
			urlVideoActual = ((JLabel) panelAnterior.getComponent(0)).getText();
			codigoVideo = Integer.valueOf(((JLabel) panelAnterior.getComponent(1)).getText());
			Inicio.reproducirVideo(urlVideoActual);
			// Set etiquetas del v�deo
			panelEtiq.removeAll();
			for (String etiqueta : controlador.getEtiquetasVideo(codigoVideo)) {
				JFormattedTextField formatedFieldAux = new JFormattedTextField();
				panelEtiq.add(formatedFieldAux);
				formatedFieldAux.setForeground(Color.BLACK);
				formatedFieldAux.setBackground(Color.LIGHT_GRAY);
				formatedFieldAux.setText(etiqueta);
			}
			ventana.revalidate(); /*redibujar con el nuevo JPanel*/
			ventana.repaint();
			// Set n�mero de reproducciones
			labelNumero.setText(String.valueOf(controlador.getNumReproduccVideo(codigoVideo)));
			
			// Al reproducir el v�deo hay que ponerlo el primero en la lista de v�deos recientes del usuario
			controlador.a�adirVideoARecientes(codigoVideo);
			// Al reproducir el v�deo hay que incrementar en 1 el n�mero de reproducciones del mismo
			controlador.incrementarNumReproduccVideo(codigoVideo);
			// Abrir panel de reproducci�n
			panelReproduccion.setVisible(true);
		}
	}
	
	/*
	 * Obtener los diez v�deos m�s vistos de la plataforma y a�adirlos a la lista de miniaturas del lateral
	 */
	private void obtenerTopTen() {
		
		// Realizamos la b�squeda y obtenemos un HashMap con la url y el c�digo del v�deo
		LinkedList<Integer> topten = (LinkedList<Integer>) controlador.obtenerTopTen();
				
		// Vamos recorriendo el mapa, obteniendo el t�tulo de cada v�deo, y a�adiendo la miniatura a la interfaz
		for (int codigo : topten) {
			a�adirMiniaturaLista(this, panelMiniaturasLista, controlador.getUrlVideo(codigo), controlador.getTituloVideo(codigo), codigo);
		}
		
		ventana.revalidate(); /*redibujar con el nuevo JPanel*/
		ventana.repaint();
	}
	
	
	// M�todos por defecto de la interfaz MouseListener
	
	@Override
	public void mouseEntered(MouseEvent arg0) {
		// Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent arg0) {
		// Auto-generated method stub
		
	}

	@Override
	public void mousePressed(MouseEvent arg0) {
		// Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent arg0) {
		// Auto-generated method stub
		
	}
	
}
