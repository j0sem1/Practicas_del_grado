package vista;

import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map.Entry;

import javax.swing.AbstractListModel;
import javax.swing.DefaultListModel;
import javax.swing.GroupLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.UIManager;
import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;

import controlador.ControladorAppVideo;

@SuppressWarnings("serial")
public class VentanaExplorar extends Ventana implements MouseListener {
	
	private String nombreVentana;
	
	private JLabel labelBuscar;
	private JLabel labelEtiqDisp;
	private JLabel labelEtiqSelec;
	
	private JTextField fieldBuscar;
	
	private JButton btnBuscar;
	private JButton btnNuevaBusqueda;
	
	private JList<String> listDisp;
	private JList<String> listSelec;
	
	private DefaultListModel<String> modelListSelec;
	
	private JScrollPane scrollPaneEtiqDispon;
	private JScrollPane scrollPaneEtiqSelecc;
	private JScrollPane scrollPaneVideos;
	
	private JPanel panelMiniaturas;
	private JPanel panelAnterior;

	public VentanaExplorar(JFrame ventana, ControladorAppVideo controlador) {
		// Inicializamos la variable controlador
		this.controlador = controlador;
		// Inicializar las variables
		this.ventana = ventana;
		nombreVentana = "Explorar";
		panelAnterior = null;
		// Inicializar el panel de la ventana actual
		initialize();
	}
	
	String getNombreVentana() {
		return nombreVentana;
	}
	
	/*
	 * Elementos visuales a�adidos a la clase padre Ventana
	 */
	void comportamientoParticular(JPanel panel_1){
		labelBuscar = new JLabel("Buscar t\u00EDtulo");
		
		fieldBuscar = new JTextField();
		fieldBuscar.setColumns(10);
		
		btnBuscar = new JButton("Buscar");
		btnBuscar.addActionListener(this);
		
		btnNuevaBusqueda = new JButton("Nueva b\u00FAsqueda");
		btnNuevaBusqueda.addActionListener(this);
		
		labelEtiqDisp = new JLabel("Etiquetas disponibles");
		
		labelEtiqSelec = new JLabel("Etiquetas seleccionadas");
		
		scrollPaneEtiqDispon = new JScrollPane();
		scrollPaneEtiqSelecc = new JScrollPane();
		scrollPaneVideos = new JScrollPane();
		
		GroupLayout gl_panel_1 = new GroupLayout(panel_1);
		gl_panel_1.setHorizontalGroup(
			gl_panel_1.createParallelGroup(Alignment.TRAILING)
				.addGroup(gl_panel_1.createSequentialGroup()
					.addGroup(gl_panel_1.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_panel_1.createSequentialGroup()
							.addContainerGap()
							.addComponent(labelBuscar)
							.addGap(18)
							.addComponent(fieldBuscar, GroupLayout.PREFERRED_SIZE, 397, GroupLayout.PREFERRED_SIZE)
							.addGap(18)
							.addComponent(btnBuscar))
						.addGroup(gl_panel_1.createSequentialGroup()
							.addGap(229)
							.addComponent(btnNuevaBusqueda)
							.addGap(145))
						.addGroup(gl_panel_1.createSequentialGroup()
							.addContainerGap()
							.addComponent(scrollPaneVideos, GroupLayout.DEFAULT_SIZE, 598, GroupLayout.DEFAULT_SIZE)))
					.addGap(18)
					.addGroup(gl_panel_1.createParallelGroup(Alignment.TRAILING, false)
						.addGroup(gl_panel_1.createSequentialGroup()
							.addComponent(labelEtiqSelec)
							.addPreferredGap(ComponentPlacement.RELATED))
						.addComponent(labelEtiqDisp)
						.addGroup(gl_panel_1.createSequentialGroup()
							.addGroup(gl_panel_1.createParallelGroup(Alignment.TRAILING, false)
								.addComponent(scrollPaneEtiqDispon, GroupLayout.PREFERRED_SIZE, 138, GroupLayout.PREFERRED_SIZE)
								.addComponent(scrollPaneEtiqSelecc, Alignment.LEADING, GroupLayout.PREFERRED_SIZE, 138, GroupLayout.PREFERRED_SIZE))
							.addPreferredGap(ComponentPlacement.RELATED)))
					.addGap(14))
		);
		gl_panel_1.setVerticalGroup(
			gl_panel_1.createParallelGroup(Alignment.TRAILING)
				.addGroup(gl_panel_1.createSequentialGroup()
					.addGroup(gl_panel_1.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_panel_1.createSequentialGroup()
							.addGap(30)
							.addComponent(labelEtiqDisp)
							.addPreferredGap(ComponentPlacement.UNRELATED)
							.addComponent(scrollPaneEtiqDispon, GroupLayout.DEFAULT_SIZE, 129, Short.MAX_VALUE)
							.addGap(27)
							.addComponent(labelEtiqSelec)
							.addGap(18)
							.addComponent(scrollPaneEtiqSelecc, GroupLayout.DEFAULT_SIZE, 151, Short.MAX_VALUE))
						.addGroup(gl_panel_1.createSequentialGroup()
							.addGap(13)
							.addGroup(gl_panel_1.createParallelGroup(Alignment.BASELINE)
								.addComponent(fieldBuscar, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
								.addComponent(labelBuscar)
								.addComponent(btnBuscar))
							.addGap(15)
							.addComponent(btnNuevaBusqueda)
							.addPreferredGap(ComponentPlacement.UNRELATED)
							.addComponent(scrollPaneVideos, GroupLayout.DEFAULT_SIZE, 309, Short.MAX_VALUE)))
					.addContainerGap())
		);
		
		listDisp = new JList<String>();
		listDisp.addMouseListener(this);
		listDisp.setModel(new AbstractListModel<String>() {
	    	String[] values = obtenerEtiquetas();
	    	public int getSize() {
	    		return values.length;
	    	}
	    	public String getElementAt(int index) {
	    		return values[index];
	    	}
	    });
		
		modelListSelec = new DefaultListModel<String>();
		
		listSelec = new JList<String>(modelListSelec);
		listSelec.addMouseListener(this);
		
		scrollPaneEtiqSelecc.setViewportView(listSelec);
		scrollPaneEtiqDispon.setViewportView(listDisp);
	    
		panel_1.setLayout(gl_panel_1);
		
		panelMiniaturas = new JPanel();
		scrollPaneVideos.setViewportView(panelMiniaturas);
		panelMiniaturas.setSize(new Dimension(Constantes.width_panelMiniaturasVideos, Constantes.height_panelMiniaturasVideos));
		panelMiniaturas.setLayout(new WrapLayout());
	}
	
	@Override
	public void mouseClicked(MouseEvent e) {
		// Si se ha pulsado en la lista de Etiquetas seleccionadas
		if (e.getSource() == listSelec) {
			// Y se ha hecho click con el bot�n derecho
			if (e.getButton() == MouseEvent.BUTTON3)
				// Si se ha seleccionado alguna etiqueta se elimina de la lista
				if (!listSelec.isSelectionEmpty())
					modelListSelec.remove(listSelec.getSelectedIndex());
			
		// Si se ha pulsado en la lista de Etiquetas disponibles
		} else if (e.getSource() == listDisp) {
			// Y se ha hecho doble click
			if (e.getClickCount() == 2)
				// Se a�ade la etiqueta seleccionada a la lista de etiquetas seleccionadas
				// (si no est� a�adida ya)
    			if (!modelListSelec.contains(listDisp.getModel().getElementAt(listDisp.getSelectedIndex())))
    				modelListSelec.addElement(listDisp.getModel().getElementAt(listDisp.getSelectedIndex()));
			
		// Si se ha pulsado un v�deo
		} else if (e.getSource().getClass() == JPanel.class) {
			// Obtenemos el panel que ha sido pulsado
			JPanel panelPulsado = (JPanel) e.getSource();
			// Si ya hab�a un v�deo seleccionado
			if (panelAnterior != null) {
				// y es distinto al que se ha seleccionado ahora
				if (panelAnterior != panelPulsado) {
					// Se cambia el fondo del v�deo seleccionado para que aparezca como tal
					// y se deja el fondo original para el v�deo que estaba ya seleccionado
					panelAnterior.setBackground(panelAnterior.getParent().getBackground());
					panelPulsado.setBackground(UIManager.getColor("activeCaption"));
				}
			} else
				panelPulsado.setBackground(UIManager.getColor("activeCaption"));
			panelAnterior = panelPulsado;
			// Si se ha hecho doble click en el v�deo se reproduce
			if (e.getClickCount() == 2) {
				String urlVideo = ((JLabel) panelAnterior.getComponent(0)).getText();
				int codigoVideo = Integer.valueOf(((JLabel) panelAnterior.getComponent(1)).getText());
				// A la ventana Reproductor se le pasa la url del v�deo
				Inicio.setVentanaReproductor(urlVideo, codigoVideo);
    			// Al reproducir el v�deo hay que ponerlo el primero en la lista de v�deos recientes del usuario
				controlador.a�adirVideoARecientes(codigoVideo);
				// Al reproducir el v�deo hay que incrementar en 1 el n�mero de reproducciones del mismo
				controlador.incrementarNumReproduccVideo(codigoVideo);
			}
		}
	}
	
	void accionesVentanas(ActionEvent e) {
		if (e.getSource() == btnBuscar) {
			// Buscar los v�deos
			realizarBusqueda();
		} else if (e.getSource() == btnNuevaBusqueda) { 
			// Limpiar los campos
			limpiar();
			panelMiniaturas.removeAll();
			ventana.revalidate(); /*redibujar con el nuevo JPanel*/
			ventana.repaint();
		}
	}
	
	/*
	 * Realizar una b�squeda de v�deos filtrando por etiquetas si se ha seleccionado alguna
	 */
	private void realizarBusqueda() {
		// Limpiar el panel
		panelMiniaturas.removeAll();
		
		// Obtenemos las etiquetas que ha seleccionado el usuario
		String[] stringArray = Arrays.copyOf(modelListSelec.toArray(), modelListSelec.toArray().length, String[].class);
		
		// Realizamos la b�squeda y obtenemos un HashMap con la url y el c�digo del v�deo
		HashMap<String, String> videos = controlador.realizarBusqueda(fieldBuscar.getText(), stringArray);
		
		// Creamos un iterador
		Iterator<Entry<String, String>> it = videos.entrySet().iterator();
		
		// Vamos recorriendo el mapa, obteniendo el t�tulo de cada v�deo, y a�adiendo la miniatura a la interfaz
		while (it.hasNext()) {
			HashMap.Entry<String, String> video = (HashMap.Entry<String, String>) it.next();
			int codigo = Integer.valueOf(video.getKey());
			a�adirMiniaturaVideos(this, panelMiniaturas, video.getValue(), controlador.getTituloVideo(codigo), codigo);
		}
		
		ventana.revalidate(); /*redibujar con el nuevo JPanel*/
		ventana.repaint();
	}
	
	/*
	 * Limpiar los campos de b�squeda (barra de b�squeda y lista de etiquetas seleccionadas
	 */
	private void limpiar() {
		fieldBuscar.setText(null);
		modelListSelec.clear();
	}
	
	/*
	 * M�todo para obtener las etiquetas hay actualmente en el sistema
	 */
	private String[] obtenerEtiquetas() {
		List<String> listaEtiquetas = controlador.obtenerEtiquetas();
		return listaEtiquetas.toArray(new String[listaEtiquetas.size()]);
	}

	
	// M�todos por defecto de la interfaz MouseListener
	
	@Override
	public void mouseEntered(MouseEvent arg0) {
		// Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent arg0) {
		// Auto-generated method stub
		
	}

	@Override
	public void mousePressed(MouseEvent arg0) {
		// Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent arg0) {
		// Auto-generated method stub
		
	}
}
