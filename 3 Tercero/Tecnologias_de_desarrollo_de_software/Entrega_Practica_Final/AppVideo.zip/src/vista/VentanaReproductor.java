package vista;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;

import javax.swing.GroupLayout;
import javax.swing.JButton;
import javax.swing.JFormattedTextField;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;

import controlador.ControladorAppVideo;

@SuppressWarnings("serial")
public class VentanaReproductor extends Ventana{
	
	private String nombreVentana;
	private String urlVideoActual;
	
	private JLabel labelTituloVideo;
	private JLabel labelNuevaEtiq;
	private JLabel labelNVisualiz;
	private JLabel labelNumero;
	
	private JTextField fieldNuevaEtiq;
	
	private JButton btnA�adirEtiq;
	
	private JPanel panelReproductor;
	private JPanel panelVideo;
	private JScrollPane scrollPaneEtiq;
	private JPanel panelEtiq;
	
	private int codigoVideo;

	public VentanaReproductor(JFrame ventana, ControladorAppVideo controlador) {
		// Inicializamos la variable controlador
		this.controlador = controlador;
		// Inicializar las variables
		this.ventana = ventana;
		nombreVentana = "Mis listas";
		// Inicializar el panel de la ventana actual
		initialize();
	}
	
	String getNombreVentana() {
		return nombreVentana;
	}
	
	/*
	 * Elementos visuales a�adidos a la clase padre Ventana
	 */
	void comportamientoParticular(JPanel panel_1){
		
		panelReproductor = new JPanel();
		panelReproductor.setBackground(Color.LIGHT_GRAY);
		panelVideo = new JPanel();
		scrollPaneEtiq = new JScrollPane();
		panelEtiq = new JPanel();
		
		GroupLayout gl_panel_1 = new GroupLayout(panel_1);
		gl_panel_1.setHorizontalGroup(
			gl_panel_1.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel_1.createSequentialGroup()
					.addContainerGap()
					.addComponent(panelReproductor, GroupLayout.DEFAULT_SIZE, 774, Short.MAX_VALUE)
					.addContainerGap())
		);
		gl_panel_1.setVerticalGroup(
			gl_panel_1.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel_1.createSequentialGroup()
					.addComponent(panelReproductor, GroupLayout.DEFAULT_SIZE, 400, Short.MAX_VALUE)
					.addContainerGap())
		);
		
		labelTituloVideo = new JLabel("T\u00EDtulo del v\u00EDdeo");
		labelTituloVideo.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 26));
		labelTituloVideo.setHorizontalAlignment(SwingConstants.CENTER);
		
		labelNuevaEtiq = new JLabel("Nueva etiqueta");
		
		fieldNuevaEtiq = new JTextField();
		fieldNuevaEtiq.setColumns(10);
		
		btnA�adirEtiq = new JButton("A\u00F1adir");
		btnA�adirEtiq.addActionListener(this);
		
		labelNVisualiz = new JLabel("N\u00FAmero de visualizaciones:");
		labelNVisualiz.setHorizontalAlignment(SwingConstants.RIGHT);
		
		labelNumero = new JLabel();
		labelNumero.setHorizontalAlignment(SwingConstants.LEFT);
		
		GroupLayout gl_panel_2 = new GroupLayout(panelReproductor);
		gl_panel_2.setHorizontalGroup(
				gl_panel_2.createParallelGroup(Alignment.TRAILING)
					.addGroup(gl_panel_2.createSequentialGroup()
						.addContainerGap()
						.addGroup(gl_panel_2.createParallelGroup(Alignment.LEADING)
							.addComponent(scrollPaneEtiq, GroupLayout.DEFAULT_SIZE, 545, Short.MAX_VALUE)
							.addGroup(gl_panel_2.createSequentialGroup()
								.addComponent(labelNuevaEtiq)
								.addGap(26)
								.addComponent(fieldNuevaEtiq, GroupLayout.PREFERRED_SIZE, 318, GroupLayout.PREFERRED_SIZE)
								.addPreferredGap(ComponentPlacement.RELATED, 47, Short.MAX_VALUE)
								.addComponent(btnA�adirEtiq))
							.addComponent(labelTituloVideo, GroupLayout.DEFAULT_SIZE, 545, Short.MAX_VALUE)
							.addComponent(panelVideo, GroupLayout.DEFAULT_SIZE, 545, Short.MAX_VALUE)
							.addGroup(gl_panel_2.createSequentialGroup()
								.addComponent(labelNVisualiz, GroupLayout.DEFAULT_SIZE, 300, Short.MAX_VALUE)
								.addGap(18)
								.addComponent(labelNumero, GroupLayout.DEFAULT_SIZE, 227, Short.MAX_VALUE)))
						.addContainerGap())
			);
		gl_panel_2.setVerticalGroup(
				gl_panel_2.createParallelGroup(Alignment.LEADING)
					.addGroup(gl_panel_2.createSequentialGroup()
						.addContainerGap()
						.addComponent(labelTituloVideo)
						.addPreferredGap(ComponentPlacement.RELATED)
						.addComponent(panelVideo, GroupLayout.PREFERRED_SIZE, 230, GroupLayout.PREFERRED_SIZE)
						.addGap(18)
						.addComponent(scrollPaneEtiq, GroupLayout.PREFERRED_SIZE, 44, GroupLayout.PREFERRED_SIZE)
						.addGap(18)
						.addGroup(gl_panel_2.createParallelGroup(Alignment.BASELINE)
							.addComponent(labelNVisualiz)
							.addComponent(labelNumero))
						.addGap(18, 18, Short.MAX_VALUE)
						.addGroup(gl_panel_2.createParallelGroup(Alignment.BASELINE)
							.addComponent(labelNuevaEtiq)
							.addComponent(fieldNuevaEtiq, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
							.addComponent(btnA�adirEtiq))
						.addContainerGap())
			);;
		
		scrollPaneEtiq.setViewportView(panelEtiq);
		panelReproductor.setLayout(gl_panel_2);
	    
		panel_1.setLayout(gl_panel_1);
		
		// A�adimos el componente VideoWeb al JPanel panel_5, que es donde se debe reproducir el v�deo
		panelVideo.add(Inicio.getVideoWeb());
		
	}
	
	void accionesVentanas(ActionEvent e) {
		if (e.getSource() == btnA�adirEtiq) {
			a�adirEtiqueta(panelEtiq, fieldNuevaEtiq.getText(), urlVideoActual, codigoVideo);
			fieldNuevaEtiq.setText(null);
		}
	}
	
	/*
	 * Reproduce el v�deo pasado como par�metro
	 */
	public void reproducir(String url, int codigo) {
		Inicio.reproducirVideo(url);
		// Set el c�digo del v�deo que se est� reproduciendo actualmente
		codigoVideo = codigo;
		// Set la url del v�deo que se est� reproduciendo actualmente
		urlVideoActual = url;
		// Set etiquetas del v�deo
		panelEtiq.removeAll();
		for (String etiqueta : controlador.getEtiquetasVideo(codigoVideo)) {
			JFormattedTextField formatedFieldAux = new JFormattedTextField();
			panelEtiq.add(formatedFieldAux);
			formatedFieldAux.setForeground(Color.BLACK);
			formatedFieldAux.setBackground(Color.LIGHT_GRAY);
			formatedFieldAux.setText(etiqueta);
		}
		ventana.revalidate(); /*redibujar con el nuevo JPanel*/
		ventana.repaint();
		// Set n�mero de reproducciones
		labelNumero.setText(String.valueOf(controlador.getNumReproduccVideo(codigoVideo)));
	}
}
