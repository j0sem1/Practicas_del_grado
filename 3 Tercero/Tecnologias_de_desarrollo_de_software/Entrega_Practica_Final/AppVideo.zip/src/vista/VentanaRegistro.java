package vista;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.util.Arrays;
import java.util.Calendar;

import javax.swing.GroupLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;

import com.toedter.calendar.JDateChooser;

import controlador.ControladorAppVideo;

@SuppressWarnings("serial")
public class VentanaRegistro extends Ventana{
	
	private String nombreVentana;
	
	private JLabel labelNombre;
	private JLabel labelApellidos;
	private JLabel labelFechaNacimiento;
	private JLabel labelEmail;
	private JLabel labelUsuario;
	private JLabel labelPasswd;
	private JLabel labelRepeatPasswd;
	private JLabel labelCamposOblig;
	
	private JButton btnAceptar;
	private JButton btnCancelar;
	
	private JDateChooser fecha_nacimiento;
	
	private JPasswordField fieldPasswd;
	private JPasswordField fieldRepeatPasswd;
	
	private JTextField fieldNombre;
	private JTextField fieldApellidos;
	private JTextField fieldEmail;
	private JTextField fieldUsuario;
	

	public VentanaRegistro(JFrame ventana, ControladorAppVideo controlador) {
		// Inicializamos la variable controlador
		this.controlador = controlador;
		// Inicializar las variables
		this.ventana = ventana;
		nombreVentana = "Registrar usuario";
		// Inicializar el panel de la ventana actual
		initialize();
	}
	
	String getNombreVentana() {
		return nombreVentana;
	}
	
	/*
	 * Elementos visuales a�adidos a la clase padre Ventana
	 */
	void comportamientoParticular(JPanel panel_1){
		labelUsuario = new JLabel("*Usuario");
		labelUsuario.setFont(new Font("Tahoma", Font.PLAIN, 15));
		
		labelPasswd = new JLabel("*Contrase\u00F1a");
		labelPasswd.setFont(new Font("Tahoma", Font.PLAIN, 15));
		
		btnAceptar = new JButton("Aceptar");
		btnAceptar.addActionListener(this);
		
		btnCancelar = new JButton("Cancelar");
		btnCancelar.addActionListener(this);
		
		labelRepeatPasswd = new JLabel("*Repetir contrase\u00F1a");
		labelRepeatPasswd.setFont(new Font("Tahoma", Font.PLAIN, 15));
		
		labelNombre = new JLabel("*Nombre");
		labelNombre.setFont(new Font("Tahoma", Font.PLAIN, 15));
		
		labelApellidos = new JLabel("Apellidos");
		labelApellidos.setFont(new Font("Tahoma", Font.PLAIN, 15));
		
		labelFechaNacimiento = new JLabel("*Fecha de nacimiento");
		labelFechaNacimiento.setFont(new Font("Tahoma", Font.PLAIN, 15));
		
		labelEmail = new JLabel("Email");
		labelEmail.setFont(new Font("Tahoma", Font.PLAIN, 15));
		
		fieldNombre = new JTextField();
		fieldNombre.setColumns(10);
		
		fieldApellidos = new JTextField();
		fieldApellidos.setColumns(10);
		
		fecha_nacimiento = new JDateChooser();
		
		fieldEmail = new JTextField();
		fieldEmail.setColumns(10);
		
		fieldUsuario = new JTextField();
		fieldUsuario.setColumns(10);
		
		fieldPasswd = new JPasswordField();
		
		fieldRepeatPasswd = new JPasswordField();
		
		labelCamposOblig = new JLabel("* Campos obligatorios");
		
		GroupLayout gl_panel_1 = new GroupLayout(panel_1);
		gl_panel_1.setHorizontalGroup(
			gl_panel_1.createParallelGroup(Alignment.TRAILING)
				.addGroup(gl_panel_1.createSequentialGroup()
					.addPreferredGap(ComponentPlacement.RELATED, 192, Short.MAX_VALUE)
					.addGroup(gl_panel_1.createParallelGroup(Alignment.TRAILING)
						.addComponent(labelNombre)
						.addComponent(labelApellidos)
						.addComponent(labelFechaNacimiento)
						.addComponent(labelEmail)
						.addComponent(labelUsuario)
						.addComponent(labelPasswd)
						.addGroup(gl_panel_1.createParallelGroup(Alignment.LEADING)
							.addComponent(btnAceptar)
							.addComponent(labelRepeatPasswd)
							.addComponent(labelCamposOblig)))
					.addGroup(gl_panel_1.createParallelGroup(Alignment.TRAILING, false)
						.addGroup(gl_panel_1.createSequentialGroup()
							.addGap(29)
							.addGroup(gl_panel_1.createParallelGroup(Alignment.LEADING)
								.addComponent(fecha_nacimiento, GroupLayout.DEFAULT_SIZE, 252, Short.MAX_VALUE)
								.addComponent(fieldEmail, GroupLayout.DEFAULT_SIZE, 252, Short.MAX_VALUE)
								.addComponent(fieldApellidos, GroupLayout.DEFAULT_SIZE, 252, Short.MAX_VALUE)
								.addComponent(fieldNombre, GroupLayout.DEFAULT_SIZE, 252, Short.MAX_VALUE)
								.addComponent(fieldUsuario, GroupLayout.DEFAULT_SIZE, 252, Short.MAX_VALUE)
								.addComponent(fieldPasswd, GroupLayout.DEFAULT_SIZE, 252, Short.MAX_VALUE)
								.addComponent(fieldRepeatPasswd, GroupLayout.DEFAULT_SIZE, 252, Short.MAX_VALUE)))
						.addGroup(gl_panel_1.createSequentialGroup()
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(btnCancelar)))
					.addPreferredGap(ComponentPlacement.RELATED, 177, Short.MAX_VALUE))
		);
		gl_panel_1.setVerticalGroup(
			gl_panel_1.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel_1.createSequentialGroup()
						.addPreferredGap(ComponentPlacement.RELATED, 37, Short.MAX_VALUE)
					.addGroup(gl_panel_1.createParallelGroup(Alignment.BASELINE)
						.addComponent(labelNombre)
						.addComponent(fieldNombre, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(18)
					.addGroup(gl_panel_1.createParallelGroup(Alignment.BASELINE)
						.addComponent(labelApellidos)
						.addComponent(fieldApellidos, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(18)
					.addGroup(gl_panel_1.createParallelGroup(Alignment.BASELINE)
						.addComponent(labelFechaNacimiento)
						.addComponent(fecha_nacimiento, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(18)
					.addGroup(gl_panel_1.createParallelGroup(Alignment.BASELINE)
						.addComponent(labelEmail)
						.addComponent(fieldEmail, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(18)
					.addGroup(gl_panel_1.createParallelGroup(Alignment.BASELINE)
						.addComponent(fieldUsuario, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(labelUsuario))
					.addGap(18)
					.addGroup(gl_panel_1.createParallelGroup(Alignment.BASELINE)
						.addComponent(fieldPasswd, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(labelPasswd))
					.addGap(18)
					.addGroup(gl_panel_1.createParallelGroup(Alignment.BASELINE)
						.addComponent(fieldRepeatPasswd, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(labelRepeatPasswd, GroupLayout.PREFERRED_SIZE, 19, GroupLayout.PREFERRED_SIZE))
					.addGap(18)
					.addComponent(labelCamposOblig)
					.addPreferredGap(ComponentPlacement.RELATED, 10, Short.MAX_VALUE)
					.addGroup(gl_panel_1.createParallelGroup(Alignment.BASELINE)
						.addComponent(btnAceptar)
						.addComponent(btnCancelar))
					.addPreferredGap(ComponentPlacement.RELATED, 21, Short.MAX_VALUE))
		);
		panel_1.setLayout(gl_panel_1);
	}
	
	void accionesVentanas(ActionEvent e) {
		if (e.getSource() == btnCancelar) {
			// Volver a la pantalla de inicio
			Inicio.setVentanaPrincipal();
		} else if (e.getSource() == btnAceptar) {
			// Registrar al usuario
			if (!camposVacios()) {	// Si los campos no est�n vac�os se procede al registro
				// Se ejecuta el m�todo 'registrarUsuario()' definido m�s adelante, y dependiendo del c�digo
				// devuelto se proceder� en consecuencia
				int resultado = registrarUsuario();
				// Si el usuario ha sido registrado correctamente
				if (resultado == 1) {
					// Se muestra una ventana que avisa del registro
					JOptionPane.showMessageDialog(ventana, "Usuario registrado correctamente", "Registrado", JOptionPane.INFORMATION_MESSAGE);
					// Se limpian los campos
					limpiarCampos();
					// Se va a la ventana de login para que usuario inicie sesi�n
					Inicio.setVentanaLogin();
				}
				// Si los datos coinciden con los de un usuario ya registrado se le comunica al usuario
				else if (resultado == 0)
					JOptionPane.showMessageDialog(ventana, "Los datos introducidos son iguales a un usuario ya registrado", "Usuario ya registrado", JOptionPane.INFORMATION_MESSAGE);
				// Si las contrase�as no son iguales se le muestra un error
				else if (resultado == -1)
					JOptionPane.showMessageDialog(ventana, "Las contrase�as introducidas no coinciden", "Error al registrar usuario", JOptionPane.ERROR_MESSAGE);
			}
			else
				// Si los campos est�n vac�os se muestra una ventana de error
				JOptionPane.showMessageDialog(ventana, "Los campos obligatorios no pueden estar vac�os", "Error", JOptionPane.ERROR_MESSAGE);
		}
	}
	
	/*
	 * M�todo que comprueba si los campos obligatorios est�n vac�os
	 */
	private boolean camposVacios() {
		if (fieldNombre.getText().trim().isEmpty()) return true;
		else if (fecha_nacimiento.getDate() == null) return true;
		else if (fieldUsuario.getText().trim().isEmpty()) return true;
		else if (fieldPasswd.getPassword().length == 0) return true;
		else if (fieldRepeatPasswd.getPassword().length == 0) return true;
		
		return false;
	}
	
	/*
	 * Devuelve 1 si el usuario se ha registrado correctamente. 
	 * Devuelve 0 si el usuario ya se encontraba registrado.
	 * Devuelve -1 si las contrase�as introducidas no eran iguales.
	 */
	private int registrarUsuario() {
		String auxNombre = fieldNombre.getText().trim();
		String auxApellidos = fieldApellidos.getText().trim();
		Calendar auxFechaNacimiento = fecha_nacimiento.getCalendar();
		String auxEmail = fieldEmail.getText().trim();
		String auxUsuario = fieldUsuario.getText().trim();
		char auxPasswd[] = fieldPasswd.getPassword();
		char auxRepeatPasswd[] = fieldRepeatPasswd.getPassword();
		if (Arrays.equals(auxPasswd, auxRepeatPasswd)) {
			if (controlador.registrarUsuario(auxNombre, auxApellidos, auxFechaNacimiento, auxEmail, auxUsuario, auxPasswd))
				return 1;
			else
				return 0;
		} else
			return -1;
	}
	
	/*
	 * M�todo que limpia todos los campos de la ventana
	 */
	private void limpiarCampos() {
		fieldNombre.setText("");
		fieldApellidos.setText("");
		fecha_nacimiento.setDate(null);
		fieldEmail.setText("");
		fieldUsuario.setText("");
		fieldPasswd.setText("");
		fieldRepeatPasswd.setText("");
	}
	
}
