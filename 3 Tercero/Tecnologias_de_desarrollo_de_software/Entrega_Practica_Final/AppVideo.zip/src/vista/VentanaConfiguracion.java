package vista;

import java.awt.Font;
import java.awt.SystemColor;
import java.awt.event.ActionEvent;

import javax.swing.AbstractListModel;
import javax.swing.GroupLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.SwingConstants;
import javax.swing.GroupLayout.Alignment;

import controlador.ControladorAppVideo;

@SuppressWarnings("serial")
public class VentanaConfiguracion extends Ventana {
	
	private String nombreVentana;
	
	private JLabel labelPremium;
	private JLabel labelEstandar;
	private JLabel labelPrecioPremium;
	private JLabel labelPrecioEstandar;
	private JLabel labelTipoUsuario;
	private JLabel labelSeleccFiltro;
	private JLabel labelFiltroActual;
	
	private JButton btnPremium;
	private JButton btnEstandar;
	private JButton btnSeleccFiltro;

	private JList<String> listaFiltros;
	
	private JPanel panelFiltros;
	
	private JScrollPane scrollPaneFiltros;
	
	public VentanaConfiguracion(JFrame ventana, ControladorAppVideo controlador) {
		// Inicializamos la variable controlador
		this.controlador = controlador;
		// Inicializar la variable JFrame que tiene la clase padre
		this.ventana = ventana;
		// Inicializar el panel de la ventana actual
		initialize();
	}
	
	String getNombreVentana() {
		nombreVentana = "Configuraci�n cuenta premium";
		return nombreVentana;
	}
	
	/*
	 * Elementos visuales a�adidos a la clase padre Ventana
	 */
	void comportamientoParticular(JPanel panel_1){
		labelPremium = new JLabel("Cuenta premium");
		labelPremium.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 18));
		
		labelEstandar = new JLabel("Cuenta est\u00E1ndar");
		labelEstandar.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 18));
		
		labelPrecioPremium = new JLabel("Precio: GRATUITA");
		
		labelPrecioEstandar = new JLabel("Precio: GRATUITA");
		
		btnPremium = new JButton("Activar");
		btnPremium.addActionListener(this);
		
		btnEstandar = new JButton("Activar");
		btnEstandar.addActionListener(this);
		
		labelTipoUsuario = new JLabel("");
		labelTipoUsuario.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 28));
		labelTipoUsuario.setHorizontalAlignment(SwingConstants.CENTER);
		
		panelFiltros = new JPanel();
		panelFiltros.setBackground(SystemColor.controlHighlight);
		
		labelFiltroActual = new JLabel("");
		labelFiltroActual.setHorizontalAlignment(SwingConstants.CENTER);
		labelFiltroActual.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 28));

		
		GroupLayout gl_panel_1 = new GroupLayout(panel_1);
		gl_panel_1.setHorizontalGroup(
			gl_panel_1.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel_1.createSequentialGroup()
					.addGroup(gl_panel_1.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_panel_1.createSequentialGroup()
							.addGap(33)
							.addGroup(gl_panel_1.createParallelGroup(Alignment.LEADING)
								.addGroup(gl_panel_1.createSequentialGroup()
									.addGap(19)
									.addComponent(labelPrecioPremium)
									.addGap(104)
									.addComponent(labelPrecioEstandar))
								.addGroup(gl_panel_1.createSequentialGroup()
									.addGap(33)
									.addComponent(btnPremium)
									.addGap(136)
									.addComponent(btnEstandar))
								.addGroup(gl_panel_1.createSequentialGroup()
									.addComponent(labelPremium)
									.addGap(64)
									.addComponent(labelEstandar))))
						.addGroup(gl_panel_1.createSequentialGroup()
							.addContainerGap()
							.addComponent(labelTipoUsuario, GroupLayout.PREFERRED_SIZE, 419, GroupLayout.PREFERRED_SIZE))
						.addGroup(gl_panel_1.createSequentialGroup()
							.addContainerGap()
							.addComponent(labelFiltroActual, GroupLayout.PREFERRED_SIZE, 419, GroupLayout.PREFERRED_SIZE)))
					.addGap(18)
					.addComponent(panelFiltros, GroupLayout.DEFAULT_SIZE, 322, Short.MAX_VALUE)
					.addContainerGap())
		);
		gl_panel_1.setVerticalGroup(
			gl_panel_1.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel_1.createSequentialGroup()
					.addGroup(gl_panel_1.createParallelGroup(Alignment.TRAILING)
						.addGroup(Alignment.LEADING, gl_panel_1.createSequentialGroup()
							.addGap(50)
							.addGroup(gl_panel_1.createParallelGroup(Alignment.BASELINE)
								.addComponent(labelPremium)
								.addComponent(labelEstandar))
							.addGap(18)
							.addGroup(gl_panel_1.createParallelGroup(Alignment.BASELINE)
								.addComponent(labelPrecioPremium)
								.addComponent(labelPrecioEstandar))
							.addGap(18)
							.addGroup(gl_panel_1.createParallelGroup(Alignment.BASELINE)
								.addComponent(btnPremium)
								.addComponent(btnEstandar))
							.addGap(89)
							.addComponent(labelTipoUsuario)
							.addGap(43)
							.addComponent(labelFiltroActual, GroupLayout.PREFERRED_SIZE, 31, GroupLayout.PREFERRED_SIZE)
							.addGap(58))
						.addGroup(gl_panel_1.createSequentialGroup()
							.addContainerGap()
							.addComponent(panelFiltros, GroupLayout.DEFAULT_SIZE, 387, Short.MAX_VALUE)))
					.addContainerGap())
		);
		
		labelSeleccFiltro = new JLabel("Seleccionar filtro");
		labelSeleccFiltro.setHorizontalAlignment(SwingConstants.CENTER);
		labelSeleccFiltro.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 18));
		
		btnSeleccFiltro = new JButton("Activar");
		btnSeleccFiltro.addActionListener(this);
		
		scrollPaneFiltros = new JScrollPane();
		GroupLayout gl_panel_2 = new GroupLayout(panelFiltros);
		gl_panel_2.setHorizontalGroup(
				gl_panel_2.createParallelGroup(Alignment.TRAILING)
					.addGroup(gl_panel_2.createSequentialGroup()
						.addContainerGap()
						.addComponent(labelSeleccFiltro, GroupLayout.DEFAULT_SIZE, 298, Short.MAX_VALUE)
						.addContainerGap())
					.addGroup(gl_panel_2.createSequentialGroup()
						.addGap(77)
						.addComponent(scrollPaneFiltros, GroupLayout.DEFAULT_SIZE, 170, Short.MAX_VALUE)
						.addGap(75))
					.addGroup(gl_panel_2.createSequentialGroup()
						.addContainerGap(122, Short.MAX_VALUE)
						.addComponent(btnSeleccFiltro, GroupLayout.PREFERRED_SIZE, 84, GroupLayout.PREFERRED_SIZE)
						.addGap(116))
			);
		gl_panel_2.setVerticalGroup(
				gl_panel_2.createParallelGroup(Alignment.LEADING)
					.addGroup(gl_panel_2.createSequentialGroup()
						.addGap(40)
						.addComponent(labelSeleccFiltro, GroupLayout.PREFERRED_SIZE, 21, GroupLayout.PREFERRED_SIZE)
						.addGap(18)
						.addComponent(scrollPaneFiltros, GroupLayout.DEFAULT_SIZE, 211, Short.MAX_VALUE)
						.addGap(18)
						.addComponent(btnSeleccFiltro)
						.addGap(54))
			);
		
		listaFiltros = new JList<String>();
		listaFiltros.setBackground(SystemColor.menu);
		listaFiltros.setModel(new AbstractListModel<String>() {
	    	String[] values = obtenerFiltros();
	    	public int getSize() {
	    		return values.length;
	    	}
	    	public String getElementAt(int index) {
	    		return values[index];
	    	}
	    });
		
		scrollPaneFiltros.setViewportView(listaFiltros);
		panelFiltros.setLayout(gl_panel_2);
		
		panel_1.setLayout(gl_panel_1);
	}
	
	void accionesVentanas(ActionEvent e) {
		if (e.getSource() == btnEstandar) {
			// Convertir al usuario en Estandar
			controlador.setUsuarioEstandar();
			Inicio.setUsuarioEstandar();
			setTipoUsuario("ESTANDAR");
			setFiltroUsuario("Sin filtro");
			ventana.revalidate(); /*redibujar con el nuevo JPanel*/
			ventana.repaint();
		} else if (e.getSource() == btnPremium) {
			// Convertir al usuario en Premium
			controlador.setUsuarioPremium();
			Inicio.setUsuarioPremium();
			setTipoUsuario("PREMIUM");
			ventana.revalidate(); /*redibujar con el nuevo JPanel*/
			ventana.repaint();
		} else if (e.getSource() == btnSeleccFiltro) {
			// Si el usuario es premium se dejar� seleccionar un filtro
			if (Inicio.isUsuarioPremium()) {
				seleccionarFiltro((String) listaFiltros.getModel().getElementAt(listaFiltros.getSelectedIndex()));
				listaFiltros.clearSelection();
				ventana.revalidate(); /*redibujar con el nuevo JPanel*/
				ventana.repaint();
			// Si no es premium saltar� una ventana de error, no dejando seleccionar un filtro
			} else
				JOptionPane.showMessageDialog(ventana, "Debes ser premium para poder elegir un filtro", "Error", JOptionPane.ERROR_MESSAGE);
		}
	}
	
	/*
	 * Establece el tipo de usuario (Premium o Estandar) en la etiqueta de la ventana
	 */
	public void setTipoUsuario(String tipoUsuario) {
		labelTipoUsuario.setText("Usted es un usuario " + tipoUsuario);
	}
	
	/*
	 * Establece el filtro actual del usuario en la etiqueta de la ventana
	 */
	public void setFiltroUsuario(String filtro) {
		labelFiltroActual.setText("Filtro actual: " + filtro);
	}
	
	
	//Funciones auxiliares
	
	private String[] obtenerFiltros() {
		return controlador.obtenerFiltros();
	}
	
	private void seleccionarFiltro(String filtro) {
		controlador.seleccionarFiltro(filtro);
		setFiltroUsuario(filtro);
	}
}
