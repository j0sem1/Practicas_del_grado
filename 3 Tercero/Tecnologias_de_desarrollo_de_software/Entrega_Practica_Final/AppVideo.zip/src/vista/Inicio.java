package vista;

import java.awt.EventQueue;
import java.awt.event.WindowAdapter;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

import controlador.ControladorAppVideo;
import tds.video.VideoWeb;

public class Inicio {
	
	private static JFrame ventana;
	
	private static VideoWeb videoWeb;
	
	private static VentanaPrincipal ventanaPrincipal;
	private static VentanaLogin ventanaLogin;
	private static VentanaRegistro ventanaRegistro;
	private static VentanaConfiguracion ventanaConfiguracion;
	private static VentanaExplorar ventanaExplorar;
	private static VentanaNuevaLista ventanaNuevaLista;
	private static VentanaMisListas ventanaMisListas;
	private static VentanaRecientes ventanaRecientes;
	private static VentanaMasVistos ventanaMasVistos;
	private static VentanaReproductor ventanaReproductor;
	
	private static boolean sesionIniciada;
	private static boolean usuarioPremium;
	private static boolean editandoLista;
	
	private static String nombreUsuario;
	
	private static ControladorAppVideo controlador;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					// Creamos el componente VideoWeb
					videoWeb = new VideoWeb();
					
					// Obtenemos la instancia del controlador
					// Esto lo hacemos para que se traigan los objetos de la BBDD al iniciar la aplicaci�n,
					// y as� despu�s el rendimiento ser� m�s fluido
					controlador = ControladorAppVideo.getUnicaInstancia();
					
					// Inicializamos las variables
					sesionIniciada = false;
					usuarioPremium = false;
					editandoLista = false;
					nombreUsuario = null;
					
					// Creamos la ventana
					crearFrame();
					
					// Construimos las ventanas que utilizaremos al principio
					ventanaPrincipal = new VentanaPrincipal(ventana, controlador);
					ventanaLogin = new VentanaLogin(ventana, controlador);
					ventanaRegistro = new VentanaRegistro(ventana, controlador);
					
					// Seleccionamos el panel que contiene la ventana principal y hacemos visible la ventana creada
					ventana.setContentPane(ventanaPrincipal);
					ventana.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	private static void crearFrame() {
		ventana = new JFrame();
		ventana.setBounds(100, 100, Constantes.ventana_x_size, Constantes.ventana_y_size);
		ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		ventana.addWindowListener(new WindowAdapter() {
		    @Override
		    public void windowClosing(java.awt.event.WindowEvent windowEvent) {
		    	if (sesionIniciada) {
		    		if (editandoLista)
		    			setAvisoGuardarCambios();
		    		controlador.cerrarSesion();
		    	}
		    }
		});
	}
	
	
	/*
	 * Funci�n que crea todas las ventanas para cuando necesiten ser usadas se pierda
	 * el menor tiempo posible en crearlas
	 */
	public static void construirVentanas() {
		ventanaPrincipal = new VentanaPrincipal(ventana, controlador);
		ventanaLogin = new VentanaLogin(ventana, controlador);
		ventanaRegistro = new VentanaRegistro(ventana, controlador);
		ventanaConfiguracion = new VentanaConfiguracion(ventana, controlador);
		ventanaExplorar = new VentanaExplorar(ventana, controlador);
		ventanaNuevaLista = new VentanaNuevaLista(ventana, controlador);
		ventanaMisListas = new VentanaMisListas(ventana, controlador);
		ventanaRecientes = new VentanaRecientes(ventana, controlador);
		ventanaReproductor = new VentanaReproductor(ventana, controlador);
	}
	
	public static VideoWeb getVideoWeb() {
		return videoWeb;
	}
	
	public static String getNombreUsuario() {
		return nombreUsuario;
	}
	
	public static boolean isSesionIniciada() {
		return sesionIniciada;
	}
	
	public static boolean isUsuarioPremium() {
		return usuarioPremium;
	}
	
	public static boolean isEditandoLista() {
		return editandoLista;
	}
	
	public static void setSesionIniciada() {
		sesionIniciada = true;
	}
	
	public static void setSesionCerrada() {
		sesionIniciada = false;
	}
	
	public static void setUsuarioPremium() {
		usuarioPremium = true;
	}
	
	public static void setUsuarioEstandar() {
		usuarioPremium = false;
	}
	
	public static void setNombreUsuario(String nombre) {
		nombreUsuario = nombre;
	}
	
	public static void setEditandoLista(boolean valor) {
		editandoLista = valor;
	}
	
	public static void setVentanaPrincipal() {
		pararVideo();
		if (ventanaPrincipal != null) {
			ventanaPrincipal.setNombre();
			Inicio.ventana.setContentPane(ventanaPrincipal);
			Inicio.ventana.revalidate(); /*redibujar con el nuevo JPanel*/
			Inicio.ventana.repaint();
		}
	}
	
	public static void setVentanaLogin() {
		pararVideo();
		if (ventanaLogin != null) {
			ventanaLogin.setNombre();
			ventanaLogin.limpiar();
			ventana.setContentPane(ventanaLogin);
			ventana.revalidate(); /*redibujar con el nuevo JPanel*/
			ventana.repaint();
		}
	}
	
	public static void setVentanaRegistro() {
		pararVideo();
		if (ventanaLogin != null) {
			ventanaRegistro.setNombre();
			ventana.setContentPane(ventanaRegistro);
			ventana.revalidate(); /*redibujar con el nuevo JPanel*/
			ventana.repaint();
		}
	}
	
	public static void setVentanaConfiguracion() {
		pararVideo();
		ventanaConfiguracion = new VentanaConfiguracion(ventana, controlador);
		if (ventanaConfiguracion != null) {
			ventanaConfiguracion.setNombre();
			if (sesionIniciada) {
				if (usuarioPremium)
					ventanaConfiguracion.setTipoUsuario("PREMIUM");
				else
					ventanaConfiguracion.setTipoUsuario("ESTANDAR");
			}
			ventanaConfiguracion.setFiltroUsuario(ControladorAppVideo.getUnicaInstancia().getFiltroUsuario());
			ventana.setContentPane(ventanaConfiguracion);
			ventana.revalidate(); /*redibujar con el nuevo JPanel*/
			ventana.repaint();
		}
	}
	
	public static void setVentanaExplorar() {
		pararVideo();
		ventanaExplorar = new VentanaExplorar(ventana, controlador);
		if (ventanaExplorar != null) {
			ventanaExplorar.setNombre();
			ventana.setContentPane(ventanaExplorar);
			ventana.revalidate(); /*redibujar con el nuevo JPanel*/
			ventana.repaint();
		}
	}
	
	public static void setVentanaNuevaLista() {
		pararVideo();
		ventanaNuevaLista = new VentanaNuevaLista(ventana, controlador);
		if (ventanaNuevaLista != null) {
			ventanaNuevaLista.setNombre();
			ventana.setContentPane(ventanaNuevaLista);
			ventana.revalidate(); /*redibujar con el nuevo JPanel*/
			ventana.repaint();
		}
	}
	
	public static void setVentanaMisListas() {
		pararVideo();
		ventanaMisListas = new VentanaMisListas(ventana, controlador);
		ventanaMisListas.setNombre();
		if (sesionIniciada) {
			if (usuarioPremium)
					ventanaMisListas.setBotonPDF();
			else
				ventanaMisListas.deleteBotonPDF();
		}
		ventana.setContentPane(ventanaMisListas);
		ventana.revalidate(); /*redibujar con el nuevo JPanel*/
		ventana.repaint();
	}
	
	public static void resetVentanaMisListas() {
		ventanaMisListas = new VentanaMisListas(ventana, controlador);
		ventanaMisListas.setNombre();
		ventana.setContentPane(ventanaMisListas);
		ventana.revalidate(); /*redibujar con el nuevo JPanel*/
		ventana.repaint();
	}
	
	public static void setVentanaRecientes() {
		pararVideo();
		ventanaRecientes = new VentanaRecientes(ventana, controlador);
		ventanaRecientes.setNombre();
		if (sesionIniciada) {
			if (usuarioPremium)
				ventanaRecientes.setBotonMasVistos();
			else
				ventanaRecientes.deleteBotonMasVistos();
		}
		ventana.setContentPane(ventanaRecientes);
		ventana.revalidate(); /*redibujar con el nuevo JPanel*/
		ventana.repaint();
	}
	
	public static void setVentanaMasVistos() {
		pararVideo();
		ventanaMasVistos = new VentanaMasVistos(ventana, controlador);
		ventanaMasVistos.setNombre();
		ventana.setContentPane(ventanaMasVistos);
		ventana.revalidate(); /*redibujar con el nuevo JPanel*/
		ventana.repaint();
	}
	
	public static void setVentanaReproductor(String url, int codigo) {
		pararVideo();
		ventanaReproductor = new VentanaReproductor(ventana, controlador);
		ventanaReproductor.setNombre();
		ventanaReproductor.reproducir(url, codigo);
		ventana.setContentPane(ventanaReproductor);
		ventana.revalidate(); /*redibujar con el nuevo JPanel*/
		ventana.repaint();
	}
	
	/*
	 * Funci�n para comenzar a reproducir el v�deo con la url pasada como par�metro
	 */
	public static void reproducirVideo(String url) {
		videoWeb.playVideo(url);
	}
	
	/*
	 * Funci�n para parar la reproducci�n en el caso de que esta se est� produciendo
	 */
	public static void pararVideo() {
		videoWeb.cancel();
	}
	
	public static void setAvisoGuardarCambios() {
		int respuesta = JOptionPane.showConfirmDialog(ventana, "�Desea guardar los cambios realizados?", "Aviso", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
		if (respuesta == JOptionPane.YES_OPTION)
			controlador.guardarCambios();
		else
			controlador.deshacerCambios();
		editandoLista = false;
	}
}