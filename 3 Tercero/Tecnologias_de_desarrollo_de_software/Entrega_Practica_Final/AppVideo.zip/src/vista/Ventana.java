package vista;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.SystemColor;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFormattedTextField;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import controlador.ControladorAppVideo;

@SuppressWarnings("serial")
public abstract class Ventana extends JPanel implements ActionListener {
	
	// M�todos que tienen que definir los hijos
	
	/*
	 * M�todo en el que las subclases implementar�n su dise�o, a�adido a la parte superior
	 * proporcionada por la clase Ventana
	 */
	abstract void comportamientoParticular(JPanel panel_1);
	
	/*
	 * M�todo que obtiene el nombre de la ventana de la subclase actual. Utilizado por la
	 * clase padre Ventana
	 */
	abstract String getNombreVentana();
	
	/*
	 * Comportamiento de las subclases en el m�todo ActionPerformed
	 */
	abstract void accionesVentanas(ActionEvent e);
	
	
	// Atributos
	
	private JLabel labelIcono;
	public JLabel labelBienvenido;
	private JLabel labelNombreVentana;
	
	private JButton btnLogin;
	private JButton btnRegistro;
	private JButton btnLogout;
	private JButton btnConfiguracion;
	private JButton btnExplorar;
	private JButton btnRecientes;
	private JButton btnMisListas;
	private JButton btnNuevaLista;
	
	private JPanel panel1;
	private JPanel panelSubclases;
	
	// Dejamos la visibilidad en protected porque es un atributo definido para las subclases
	protected JFrame ventana;
	
	protected ControladorAppVideo controlador;
	
	
	// M�todos de la clase
	
	/*
	 * M�todo que establece el nombre del usuario para ponerlo en la ventana
	 */
	public void setNombre() {
		if (Inicio.isSesionIniciada())
			// Si se ha iniciado sesi�n se muestra el nombre del usuario que habr� sido esta
			labelBienvenido.setText("Hola " + Inicio.getNombreUsuario());
		else
			// Si la sesi�n no est� iniciada se muestra bienvenido
			labelBienvenido.setText("Bienvenido");
	}
	
	/*
	 * Funci�n com�n a todas las ventanas que inicializa el panel superior (com�n a todas ellas)
	 */
	public void initialize() {
		
		GridBagLayout gridBagLayout = new GridBagLayout();
		gridBagLayout.columnWidths = new int[]{10, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 10, 0};
		gridBagLayout.rowHeights = new int[]{0, 0, 0};
		gridBagLayout.columnWeights = new double[]{0.0, 0.0, 0.0, 1.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
		gridBagLayout.rowWeights = new double[]{0.0, 1.0, Double.MIN_VALUE};
		setLayout(gridBagLayout);
		
		labelIcono = new JLabel("");
		labelIcono.setIcon(new ImageIcon(getClass().getResource("/resources/appvideo-150x75.png")));
		GridBagConstraints gbc_label = new GridBagConstraints();
		gbc_label.insets = new Insets(0, 0, 5, 5);
		gbc_label.gridx = 1;
		gbc_label.gridy = 0;
		add(labelIcono, gbc_label);
		
		if (!Inicio.isSesionIniciada()) {
			// Si la sesi�n no est� iniciada se muestra bienvenido
			labelBienvenido = new JLabel("Bienvenido");
		} else {
			// Si se ha iniciado sesi�n se muestra el nombre del usuario que habr� sido esta
			labelBienvenido = new JLabel("Hola" + Inicio.getNombreUsuario());
		}
		GridBagConstraints gbc_lblHola = new GridBagConstraints();
		gbc_lblHola.insets = new Insets(0, 0, 5, 5);
		gbc_lblHola.gridx = 4;
		gbc_lblHola.gridy = 0;
		add(labelBienvenido, gbc_lblHola);
		
		btnLogin = new JButton("Login");
		btnLogin.addActionListener(this);
		btnLogin.setForeground(new Color(0, 153, 102));
		GridBagConstraints gbc_btnLogin = new GridBagConstraints();
		gbc_btnLogin.insets = new Insets(0, 0, 5, 5);
		gbc_btnLogin.gridx = 6;
		gbc_btnLogin.gridy = 0;
		add(btnLogin, gbc_btnLogin);
		
		btnLogout = new JButton("Logout");
		btnLogout.setForeground(new Color(204, 0, 0));
		btnLogout.addActionListener(this);
		GridBagConstraints gbc_btnNewButton_1 = new GridBagConstraints();
		gbc_btnNewButton_1.insets = new Insets(0, 0, 5, 5);
		gbc_btnNewButton_1.gridx = 10;
		gbc_btnNewButton_1.gridy = 0;
		add(btnLogout, gbc_btnNewButton_1);
		
		btnRegistro = new JButton("Registro");
		btnRegistro.addActionListener(this);
		btnRegistro.setForeground(new Color(0, 51, 255));
		GridBagConstraints gbc_btnRegistro = new GridBagConstraints();
		gbc_btnRegistro.insets = new Insets(0, 0, 5, 5);
		gbc_btnRegistro.gridx = 8;
		gbc_btnRegistro.gridy = 0;
		add(btnRegistro, gbc_btnRegistro);
		
		btnConfiguracion = new JButton("Configuraci�n");
		btnConfiguracion.setForeground(new Color(153, 0, 204));
		btnConfiguracion.addActionListener(this);
		GridBagConstraints gbc_btnNewButton = new GridBagConstraints();
		gbc_btnNewButton.insets = new Insets(0, 0, 5, 5);
		gbc_btnNewButton.gridx = 12;
		gbc_btnNewButton.gridy = 0;
		add(btnConfiguracion, gbc_btnNewButton);
		
		panel1 = new JPanel();
		GridBagConstraints gbc_panel = new GridBagConstraints();
		gbc_panel.gridwidth = 14;
		gbc_panel.insets = new Insets(0, 0, 0, 5);
		gbc_panel.fill = GridBagConstraints.BOTH;
		gbc_panel.gridx = 0;
		gbc_panel.gridy = 1;
		add(panel1, gbc_panel);
		
		GridBagLayout gbl_panel = new GridBagLayout();
		gbl_panel.columnWidths = new int[]{10, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
		gbl_panel.rowHeights = new int[]{0, 0, 0, 0};
		gbl_panel.columnWeights = new double[]{0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, Double.MIN_VALUE};
		gbl_panel.rowWeights = new double[]{0.0, 0.0, 1.0, Double.MIN_VALUE};
		panel1.setLayout(gbl_panel);
		
		btnExplorar = new JButton("Explorar");
		btnExplorar.setForeground(SystemColor.text);
		btnExplorar.setBackground(Color.GRAY);
		btnExplorar.addActionListener(this);
		GridBagConstraints gbc_btnExplorar = new GridBagConstraints();
		gbc_btnExplorar.insets = new Insets(0, 0, 5, 5);
		gbc_btnExplorar.gridx = 1;
		gbc_btnExplorar.gridy = 1;
		panel1.add(btnExplorar, gbc_btnExplorar);
		
		btnRecientes = new JButton("Recientes");
		btnRecientes.setForeground(SystemColor.text);
		btnRecientes.setBackground(Color.GRAY);
		btnRecientes.addActionListener(this);
		GridBagConstraints gbc_btnRecientes = new GridBagConstraints();
		gbc_btnRecientes.insets = new Insets(0, 0, 5, 5);
		gbc_btnRecientes.gridx = 3;
		gbc_btnRecientes.gridy = 1;
		panel1.add(btnRecientes, gbc_btnRecientes);
		
		btnMisListas = new JButton("Mis listas");
		btnMisListas.setForeground(SystemColor.text);
		btnMisListas.setBackground(Color.GRAY);
		btnMisListas.addActionListener(this);
		GridBagConstraints gbc_btnMiListas = new GridBagConstraints();
		gbc_btnMiListas.insets = new Insets(0, 0, 5, 5);
		gbc_btnMiListas.gridx = 5;
		gbc_btnMiListas.gridy = 1;
		panel1.add(btnMisListas, gbc_btnMiListas);
		
		btnNuevaLista = new JButton("Nueva Lista");
		btnNuevaLista.setForeground(SystemColor.text);
		btnNuevaLista.setBackground(Color.GRAY);
		btnNuevaLista.addActionListener(this);
		GridBagConstraints gbc_btnNuevaLista = new GridBagConstraints();
		gbc_btnNuevaLista.insets = new Insets(0, 0, 5, 5);
		gbc_btnNuevaLista.gridx = 7;
		gbc_btnNuevaLista.gridy = 1;
		panel1.add(btnNuevaLista, gbc_btnNuevaLista);
		
		labelNombreVentana = new JLabel(getNombreVentana());
		GridBagConstraints gbc_lblNewLabel = new GridBagConstraints();
		gbc_lblNewLabel.gridwidth = 9;
		gbc_lblNewLabel.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel.gridx = 10;
		gbc_lblNewLabel.gridy = 1;
		panel1.add(labelNombreVentana, gbc_lblNewLabel);
		
		panelSubclases = new JPanel();
		GridBagConstraints gbc_panel_1 = new GridBagConstraints();
		gbc_panel_1.gridwidth = 19;
		gbc_panel_1.fill = GridBagConstraints.BOTH;
		gbc_panel_1.gridx = 0;
		gbc_panel_1.gridy = 2;
		panel1.add(panelSubclases, gbc_panel_1);
		
		// Las subclases implementar�n su comportamiento al ejecutarse este m�todo
		comportamientoParticular(panelSubclases);
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == btnLogin) {
			if (Inicio.isEditandoLista())
    			Inicio.setAvisoGuardarCambios();
			// Abrir ventana de login
			Inicio.setVentanaLogin();
		} else if (e.getSource() == btnLogout) {
			if (Inicio.isEditandoLista())
    			Inicio.setAvisoGuardarCambios();
			// Cerrar la sesi�n del usuario actual
			if (Inicio.isSesionIniciada()) {
				controlador.cerrarSesion();
				Inicio.setUsuarioEstandar();
				Inicio.setNombreUsuario(null);
				labelBienvenido.setText("Bienvenido");
				Inicio.setSesionCerrada();
				Inicio.setVentanaPrincipal();
			}
		} else if (e.getSource() == btnRegistro) {
			if (Inicio.isEditandoLista())
    			Inicio.setAvisoGuardarCambios();
			// Registrar un nuevo usuario
			Inicio.setVentanaRegistro();
		} else if (e.getSource() == btnConfiguracion) {
			if (Inicio.isEditandoLista())
    			Inicio.setAvisoGuardarCambios();
			// Abrir la ventana de la configuraci�n premium
			if (Inicio.isSesionIniciada()) {
				Inicio.setVentanaConfiguracion();
			}
		} else if (e.getSource() == btnExplorar) {
			if (Inicio.isEditandoLista())
    			Inicio.setAvisoGuardarCambios();
			// Abrir la ventana para explorar v�deos
			if (Inicio.isSesionIniciada()) {
				Inicio.setVentanaExplorar();
			}
		} else if (e.getSource() == btnRecientes) {
			if (Inicio.isEditandoLista())
    			Inicio.setAvisoGuardarCambios();
			// Abrir la ventana de los v�deos recientes
			if (Inicio.isSesionIniciada()) {
				Inicio.setVentanaRecientes();
			}
		} else if (e.getSource() == btnMisListas) {
			if (Inicio.isEditandoLista())
    			Inicio.setAvisoGuardarCambios();
			// Abrir la ventana con las listas de v�deos del usuario
			if (Inicio.isSesionIniciada()) {
				Inicio.setVentanaMisListas();
			}
		} else if (e.getSource() == btnNuevaLista) {
			if (Inicio.isEditandoLista())
    			Inicio.setAvisoGuardarCambios();
			// Abrir la ventana de edici�n/creaci�n de listas
			if (Inicio.isSesionIniciada()) {
				Inicio.setVentanaNuevaLista();
			}
		}
		
		// Las subclases implementar�n su comportamiento al ejecutarse este m�todo
		accionesVentanas(e);
	}
	
	/*
	 * M�todo para a�adir una miniatura de un v�deo al panel de los v�deos
	 */
	protected void a�adirMiniaturaVideos(JPanel ventana, JPanel panel, String url, String titulo, int codigo) {
		// Se obtiene el icono del v�deo con el componente VideoWeb
		ImageIcon icono = Inicio.getVideoWeb().getSmallThumb(url);
		// Se a�ade a una etiqueta
		JLabel labelIcono = new JLabel(icono);
		JLabel labelTitulo = new JLabel(titulo);
		// Aunque la url no ser� visible la almacenamos porque la necesitaremos m�s tarde
		JLabel labelUrl = new JLabel(url);
		// Hacemos lo mismo con el c�digo
		JLabel labelCodigo = new JLabel(String.valueOf(codigo));
		// Como no queremos que se vean ponemos su visibilidad a false
		labelUrl.setVisible(false);
		labelCodigo.setVisible(false);
		
		// Cada miniatura estar� formada por dos JLabel: uno para el t�tulo y otro para el icono.
		// Dichos JLabel estar�n en un JPanel con una distribuci�n BorderLayout
		// Creamos el panel de la miniatura
		JPanel panelMiniatura = new JPanel();
		panelMiniatura.setToolTipText(titulo);
		// Indicamos su tama�o y layout
		panelMiniatura.setPreferredSize(new Dimension(Constantes.width_panelMiniaturasVideos / Constantes.nVideosxLinea_miniaturaVideo, Constantes.height_miniaturaVideo));
		panelMiniatura.setLayout(new BorderLayout(0, 0));
		// A�adimos los JLabel creados
		panelMiniatura.add(labelUrl, 0);
		panelMiniatura.add(labelCodigo, 1);
		panelMiniatura.add(labelIcono, BorderLayout.NORTH);
		panelMiniatura.add(labelTitulo, BorderLayout.SOUTH);
		// Se a�ade un MouseListener (la ventana que ejecutar� el m�todo) al panel
		panelMiniatura.addMouseListener((MouseListener) ventana);
		
		// Finalmente a�adimos el panel al panel de las miniaturas
		panel.add(panelMiniatura);
	}
	
	/*
	 * A�ade una miniatura de un v�deo al panel lateral de miniaturas
	 */
	protected void a�adirMiniaturaLista(JPanel ventana, JPanel panel, String url, String titulo, int codigo) {
		// Se obtiene el icono del v�deo con el componente VideoWeb
		ImageIcon icono = Inicio.getVideoWeb().getThumb(url);
		// Se a�ade a una etiqueta
		JLabel labelIcono = new JLabel(icono);
		JLabel labelTitulo = new JLabel(titulo);
		// Aunque la url no ser� visible la almacenamos porque la necesitaremos m�s tarde
		JLabel labelUrl = new JLabel(url);
		// Hacemos lo mismo con el c�digo
		JLabel labelCodigo = new JLabel(String.valueOf(codigo));
		// Como no queremos que se vean ponemos su visibilidad a false
		labelUrl.setVisible(false);
		labelCodigo.setVisible(false);
		
		// Cada miniatura estar� formada por dos JLabel: uno para el t�tulo y otro para el icono.
		// Dichos JLabel estar�n en un JPanel con una distribuci�n BorderLayout
		// Creamos el panel de la miniatura
		JPanel panelMiniatura = new JPanel();
		panelMiniatura.setToolTipText(titulo);
		// Indicamos su tama�o y layout
		panelMiniatura.setPreferredSize(new Dimension(Constantes.size_panelMiniaturasList / Constantes.nVideosxLinea_miniaturaLista, Constantes.height_miniaturaLista));
		panelMiniatura.setLayout(new BorderLayout(0, 0));
		// A�adimos los JLabel creados
		panelMiniatura.add(labelUrl, 0);
		panelMiniatura.add(labelCodigo, 1);
		panelMiniatura.add(labelIcono, BorderLayout.NORTH);
		panelMiniatura.add(labelTitulo, BorderLayout.SOUTH);
		// Se a�ade un MouseListener (la ventana que ejecutar� el m�todo) al panel
		panelMiniatura.addMouseListener((MouseListener) ventana);
		
		// Finalmente a�adimos el panel al panel de las miniaturas
		panel.add(panelMiniatura);
	}
	
	/*
	 * A�adir etiqueta al panel de la interfaz y al v�deo
	 */
	protected void a�adirEtiqueta(JPanel panel, String textoEtiqueta, String urlVideo, int codigoVideo) {
		if ((!textoEtiqueta.equals("")) && (urlVideo != null)) {
			JFormattedTextField formatedFieldAux = new JFormattedTextField();
			panel.add(formatedFieldAux);
			formatedFieldAux.setForeground(Color.BLACK);
			formatedFieldAux.setBackground(Color.LIGHT_GRAY);
			formatedFieldAux.setText(textoEtiqueta);
			ventana.revalidate(); /*redibujar con el nuevo JPanel*/
			ventana.repaint();
			controlador.a�adirEtiquetaVideo(codigoVideo, textoEtiqueta);
		}
	}
}
