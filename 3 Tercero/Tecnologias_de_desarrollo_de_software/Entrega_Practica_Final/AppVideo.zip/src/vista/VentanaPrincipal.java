package vista;

import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.util.EventObject;

import javax.swing.JFrame;

import javax.swing.JLabel;
import javax.swing.JFileChooser;
import javax.swing.JPanel;
import javax.swing.filechooser.FileNameExtensionFilter;

import controlador.ControladorAppVideo;

import pulsador.IEncendidoListener;
import pulsador.Luz;

@SuppressWarnings("serial")
public class VentanaPrincipal extends Ventana {
	
	private String nombreVentana;
	
	private JLabel labelBienvenido;
	
	
	public VentanaPrincipal(JFrame ventana, ControladorAppVideo controlador) {
		// Inicializamos la variable controlador
		this.controlador = controlador;
		// Inicializar las variables
		this.ventana = ventana;
		// Inicializar el panel de la ventana actual
		initialize();
	}
	
	String getNombreVentana() {
		nombreVentana = "Inicio";
		return nombreVentana;
	}

	/*
	 * Elementos visuales a�adidos a la clase padre Ventana
	 */
	void comportamientoParticular(JPanel panel_1){
		
		GridBagLayout gbl_panel_1 = new GridBagLayout();
		gbl_panel_1.columnWidths = new int[]{271, 233, 0};
		gbl_panel_1.rowHeights = new int[]{187, 23, 0, 30, 0, 0, 0};
		gbl_panel_1.columnWeights = new double[]{0.0, 0.0, Double.MIN_VALUE};
		gbl_panel_1.rowWeights = new double[]{0.0, 0.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
		panel_1.setLayout(gbl_panel_1);
		
		labelBienvenido = new JLabel("BIENVENIDO A APPVIDEO");
		labelBienvenido.setFont(new Font("Verdana", Font.PLAIN, 18));
		GridBagConstraints gbc_labelBienvenido = new GridBagConstraints();
		gbc_labelBienvenido.insets = new Insets(0, 0, 5, 0);
		gbc_labelBienvenido.anchor = GridBagConstraints.NORTHWEST;
		gbc_labelBienvenido.gridx = 1;
		gbc_labelBienvenido.gridy = 1;
		panel_1.add(labelBienvenido, gbc_labelBienvenido);
		
		// Creaci�n del componente Luz
		Luz luz = new Luz();
		luz.addEncendidoListener(new IEncendidoListener() {
			// Si se pulsa el pulsador
			public void enteradoCambioEncendido(EventObject e) {
				// Se abre una ventana para que el usuario pueda escoger un archivo xml
				JFileChooser chooser = new JFileChooser();
				// Se filtrar�n todos los archivos que no tengan la extensi�n .xml
				FileNameExtensionFilter filtro = new FileNameExtensionFilter("Archivos XML", "xml");
				chooser.setFileFilter(filtro);
			    int respuesta = chooser.showOpenDialog(panel_1);
			    if (respuesta == JFileChooser.APPROVE_OPTION)
			    	// Se abrir� el archivo xml seleccionado por el usuario para a�adir los v�deos que contenga
			    	abrirXML(chooser.getSelectedFile().getAbsolutePath());
			}
		});
		
		GridBagConstraints gbc_luz = new GridBagConstraints();
		gbc_luz.gridx = 1;
		gbc_luz.gridy = 5;
		panel_1.add(luz, gbc_luz);
	}
	
	/*
	 * Env�a la ruta del xml enviado por el usuario al controlador, y que pueda as�
	 * a�adir los v�deos que contenga el archivo
	 */
	private void abrirXML(String ruta) {
		controlador.abrirXML(ruta);
	}
	
	/*
	 * Esta ventana no tiene ninguna funcionalidad a�adida para este m�todo
	 */
	void accionesVentanas(ActionEvent e) {
		// M�todo vac�o
	}
}
