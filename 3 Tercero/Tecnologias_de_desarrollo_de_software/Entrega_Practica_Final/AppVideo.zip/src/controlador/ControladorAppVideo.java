package controlador;

import java.util.Calendar;
import java.util.EventObject;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.TreeSet;

import org.apache.commons.collections4.BidiMap;
import org.apache.commons.collections4.bidimap.DualHashBidiMap;

import modelo.Etiqueta;
import modelo.ListaVideos;
import modelo.Usuario;
import modelo.Video;

import modelo.CatalogoEtiquetas;
import modelo.CatalogoUsuarios;
import modelo.CatalogoVideos;
import modelo.ComparadorVideos;
import persistencia.IAdapatadorUsuarioDAO;
import persistencia.IAdaptadorListaVideosDAO;
import persistencia.IAdaptadorVideoDAO;
import persistencia.FactoriaDAO;
import umu.tds.componentes.BuscadorVideosTDS;
import umu.tds.componentes.IBuscadorVideos;
import umu.tds.componentes.VideosEvent;
import umu.tds.componentes.VideosListener;
import persistencia.DAOException;



public class ControladorAppVideo implements VideosListener {

	private static ControladorAppVideo unicaInstancia;

	private IAdaptadorListaVideosDAO adaptadorListaVideos;
	private IAdaptadorVideoDAO adaptadorVideo;
	private IAdapatadorUsuarioDAO adaptadorUsuario;

	private CatalogoVideos catalogoVideos;
	private CatalogoUsuarios catalogoUsuarios;
	private CatalogoEtiquetas catalogoEtiquetas;
	
	private Usuario usuarioActual;
	
	private BidiMap<String, String> filtros;

	//TODO
	private IBuscadorVideos buscadorVideos; // Debe ser IBuscadorVideos, pero todav�a no lo he puesto por unas dudas
	
	// Variables solo usadas en las funciones llamadas por la ventana Nueva Lista
	private ListaVideos listaActual;
	private ListaVideos listaAnterior;
	private boolean eliminarLista;

	@SuppressWarnings("serial")
	private ControladorAppVideo() {
		// Se inicializan adaptadores, cat�logos, y el componente cargador de v�deos
		inicializarAdaptadores();
		inicializarCatalogos();
		inicializarComponenteCargadorVideos();
		// Se crea un mapa BidiMap de tipo DualHash. Eso se ha hecho para poder acceder a las Key
		// teniendo el Value. Con la clase est�ndar de Java HashMap esto no se puede realizar
		filtros = new DualHashBidiMap<String, String>();
		// Introducimos en el mapa todos los filtros que tiene actualmente el sistema
		filtros.putAll(new HashMap<String, String>(){{
            put("Sin filtro", "modelo.FiltroNoFiltro");
            put("Impopulares", "modelo.FiltroImpopulares");
            put("Menores", "modelo.FiltroMenores");
            put("Mis Listas", "modelo.FiltroMisListas");
            put("Nombres largos", "modelo.FiltroNombresLargos");
            // Cuando se cree un nuevo filtro debe a�adirse aqu�
        }});
		
		// Inicializaci�n de variables
		listaActual = null;
		listaAnterior = null;
	}

	public static ControladorAppVideo getUnicaInstancia() {
		if (unicaInstancia == null)
			unicaInstancia = new ControladorAppVideo();
		return unicaInstancia;
	}
	
	/*
	 * Inicializa los adaptadores de la BBDD
	 */
	private void inicializarAdaptadores() {
		FactoriaDAO factoria = null;
		try {
			factoria = FactoriaDAO.getInstancia(FactoriaDAO.DAO_TDS);
		} catch (DAOException e) {
			// Bloque catch generado autom�ticamente
			e.printStackTrace();
		}

		this.adaptadorVideo = factoria.getVideoDAO();
		this.adaptadorListaVideos = factoria.getListaVideosDAO();
		this.adaptadorUsuario = factoria.getUsuarioDAO();
	}

	/*
	 * Inicializa los cat�logos. Para cada uno se trae todos los objetos que hay
	 * de ese tipo en la base de datos
	 */
	private void inicializarCatalogos() {
		// Es importante inicializar primero el cat�logo de etiquetas, ya que lo necesitamos para recuperar
		// los v�deos de la BBDD
		catalogoEtiquetas = CatalogoEtiquetas.getUnicaInstacia();
		catalogoVideos = CatalogoVideos.getUnicaInstancia();
		catalogoUsuarios = CatalogoUsuarios.getUnicaInstacia();
	}

	/*
	 * Inicializa el componente Cargador de V�deos
	 */
	private void inicializarComponenteCargadorVideos() {
		this.buscadorVideos = new BuscadorVideosTDS();
		this.buscadorVideos.addArchivoListener(this);
	}

	/*
	 * Funci�n que se ejecutar� despu�s de que el componente Cargador de V�deos
	 * avise a sus oyentes
	 */
	@Override
	public void enteradoCambioArchivo(EventObject arg0) {
		// Transformamos el EventObject en un VideosEvent con un casting
		VideosEvent ve = (VideosEvent) arg0;
		// Obtenemos el objeto Videos que contiene el VideosEvent
		umu.tds.videos.Videos videos = ve.getNewLista();
		// Obtenemos la lista de v�deos que contiene el objeto Videos (los objetos Video y Videos son del componente, no de la App)
		List<umu.tds.videos.Video> listaVideos = videos.getVideo();
		// Iremos comprobando si el v�deo se encuentra ya en el cat�logo de v�deos. Si no es as�, se crea y se a�ade
		for (umu.tds.videos.Video video : listaVideos) {
			// Comprobamos si el v�deo ya se encuentra en el cat�logo
			if (catalogoVideos.getVideo(video.getUrl()) == null) {
				// Creamos uno nuevo si no es as�
				Video nuevoVideo = new Video(video.getUrl(), video.getTitulo());
				// Obtenemos las etiquetas del video y vamos recorri�ndolas una a una
				for (umu.tds.videos.Etiqueta etiquetaActual : video.getEtiqueta()) {
					// Comprobamos si est� en la aplicacion
					Etiqueta nuevaEtiqueta = catalogoEtiquetas.getEtiqueta(etiquetaActual.getNombre());
					if (nuevaEtiqueta == null) {	// Si no la tenemos, la creamos
						nuevaEtiqueta = new Etiqueta(etiquetaActual.getNombre());
						// A�adimos la etiqueta al cat�logo
						catalogoEtiquetas.addEtiqueta(nuevaEtiqueta);
					}
					// Finalmente, la a�adimos a la lista de etiquetas del v�deo
					nuevoVideo.anadirEtiqueta(nuevaEtiqueta);
				}

				// A�adimos el v�deo al cat�logo y a la base de datos
				adaptadorVideo.registrarVideo(nuevoVideo);
				//adaptadorVideo.recuperarVideo(codigo);
				catalogoVideos.addVideo(nuevoVideo);
			}
		}

	}

	/*
	 * Dado un login y un password se comprobar� que dichos valores se corresponden con un usuario registrado
	 */
	public boolean loginUsuario(String stringUsuario, char[] arrayPasswd) {
		// Convertir el password a String
		String auxPasswd = new String(arrayPasswd);
		// Obtenemos el usuario del cat�logo de usuarios
		Usuario usuario = catalogoUsuarios.getUsuario(stringUsuario);
		// Si no se ha obtenido ninguno, el nick es incorrecto y no se puede iniciar sesi�n
		if(usuario == null)
			return false;
		// Si se ha encontrado el usuario, comprobar que la contrase�a introducida se corresponde
		// con dicho usuario
		if (!usuario.comprobarPassword(auxPasswd))
			// Si la contrase�a es incorrecta no se puede iniciar sesi�n
			return false;
		// En el caso de que todo se haya producido correctamente, se almacena el usuario
		// en el Controlador y se devuelve un 'true' a la interfaz
		usuarioActual = usuario;
		return true;
	}
	
	public String getNombreUsuario() {
		if (usuarioActual != null)
			return usuarioActual.getNombre();
		return null;
	}
	
	/*
	 * Devuelve un entero >0 si el usuario es premium. Devuelve 0 si el usuario es estandar.
	 * Devuelve un entero <0 si el usuario no ha iniciado sesi�n o se ha producido un error.
	 */
	public int isPremium() {
		if (usuarioActual != null)
			if (usuarioActual.getPremium())
				return 1;
			else
				return 0;
		return  -1;
	}
	
	/*
	 * Devuelve un entero >0 si el usuario es premium. Devuelve 0 si el usuario es estandar.
	 * Devuelve un entero <0 si el usuario no ha iniciado sesi�n o se ha producido un error.
	 */
	public int isCumplea�os() {
		if (usuarioActual != null)
			if (usuarioActual.isCumplea�os())
				return 1;
			else
				return 0;
		return  -1;
	}

	/*
	 * Devuelve 'true' si el usuario se ha registrado correctamente. 
	 * Devuelve 'false' si el usuario ya se encontraba registrado.
	 */
	public boolean registrarUsuario(String nombre, String apellidos, Calendar fechaNacimiento, String email,
			String usuario, char[] passwd) {
		String auxPasswd = new String(passwd);
		// Registra al usuario en el sistema
		if(catalogoUsuarios.getUsuario(usuario) != null)
			return false;
		Usuario usuarioU = new Usuario(usuario, auxPasswd, nombre, apellidos, fechaNacimiento, email);
		adaptadorUsuario.registrarUsuario(usuarioU);
		catalogoUsuarios.addUsuario(usuarioU);
		usuarioActual = usuarioU;
		return true;
	}

	public void cerrarSesion() {
		// Modificar todos los v�deos cat�logo por si se han a�adido etiquetas o se ha
		// aumentado el n�mero de reproducciones
		for (Video video : catalogoVideos.getVideos())
			adaptadorVideo.modificarVideo(video);
		// Intentar registrar listas de videos del usuario, y si no modificarlas
		for (ListaVideos lista : usuarioActual.getListas()) {
			if (lista.getCodigo() == 0)
				adaptadorListaVideos.registrarListaVideos(lista);
			else
				adaptadorListaVideos.modificarListaVideos(lista);
		}
		// Modificar el usuario actual
		adaptadorUsuario.modificarUsuario(usuarioActual);
		this.usuarioActual = null;
	}

	public void setUsuarioPremium() {
		usuarioActual.setPremium(true);
	}

	public void setUsuarioEstandar() {
		usuarioActual.setPremium(false);
		usuarioActual.setFiltro(filtros.get("Sin filtro"));
	}

	/*
	 * Buscar los v�deos que tengan un t�tulo igual al introducido o que contengan
	 * el texto introducido en el t�tulo del v�deo. Adem�s deben tener las etiquetas
	 * indicadas.
	 */
	public HashMap<String, String> realizarBusqueda(String titulo, String[] etiquetas) {
		HashMap<String, String> videos = new HashMap<String, String>();
		for (Video video : getVideos(titulo, etiquetas)) {
			videos.put(String.valueOf(video.getCodigo()), video.getUrl());
		}
		
		return videos;
	}
	
	/*
	 * Obtiene una lista con las etiquetas que hay actualmente en el sistema
	 */
	public List<String> obtenerEtiquetas() {
		LinkedList<String> nombreEtiquetas = new LinkedList<String>();
		for (Etiqueta etiqueta : catalogoEtiquetas.getEtiquetas())
			nombreEtiquetas.add(etiqueta.getNombre());
		return nombreEtiquetas;
	}
	
	/*
	 * Obtiene las etiquetas que tiene el v�deo con el c�digo pasado como par�metro
	 */
	public List<String> getEtiquetasVideo(int codigo){
		LinkedList<String> listaNombresEtiquetas = new LinkedList<String>();
		for (Etiqueta etiqueta : catalogoVideos.getVideo(codigo).getEtiquetas())
			listaNombresEtiquetas.add(etiqueta.getNombre());
		return listaNombresEtiquetas;
	}
	
	public int getNumReproduccVideo(int codigo) {
		return catalogoVideos.getVideo(codigo).getNumReproducciones();
	}
	
	public void a�adirEtiquetaVideo(int codigo, String nombreEtiqueta) {
		catalogoVideos.getVideo(codigo).anadirEtiqueta(new Etiqueta(nombreEtiqueta));
	}
	
	public void a�adirVideoARecientes(int codigo) {
		usuarioActual.anadirVidReciente(catalogoVideos.getVideo(codigo));
	}
	
	public void incrementarNumReproduccVideo(int codigo) {
		catalogoVideos.getVideo(codigo).incrementarNumReproducc();
	}

	/*
	 * Realiza la misma b�squeda que el m�todo anterior sin realizar la b�squeda con
	 * etiquetas.
	 */
	public HashMap<String, String> realizarBusquedaSinEtiquetas(String tituloParcial) {
		HashMap<String, String> videos = new HashMap<String, String>();
		for (Video video : getVideos(tituloParcial, null))
			videos.put(String.valueOf(video.getCodigo()), video.getUrl());
		
		return videos;
	}

	/*
	 * Obtener la lista con el nombre nombreLista y devolver una lista con los v�deos
	 * de dicha ListaVideos
	 */
	public HashMap<String, String> cargarLista(String nombreLista) {
		HashMap<String, String> videos = new HashMap<String, String>();
		for (Video video : usuarioActual.getListaVideos(nombreLista).getVideos())
			videos.put(String.valueOf(video.getCodigo()), video.getUrl());
		
		return videos;
	}

	/*
	 * Obtener los �ltimos v�deos reproducidos por el usuario
	 */
	public HashMap<String, String> obtenerVideosRecientes() {
		HashMap<String, String> videos = new HashMap<String, String>();
		for (Video video : usuarioActual.getRecientes())
			videos.put(String.valueOf(video.getCodigo()), video.getUrl());
		
		return videos;
	}

	/*
	 * Obtener los diez v�deos m�s vistos por todos los usuarios
	 */
	public List<Integer> obtenerTopTen() {
		// Se crea una colecci�n TreeSet, que ordena los elementos en funci�n de un
		// comparador pasado como par�metro. En este caso se ha creado el comparador
		// ComparadorVideos
		TreeSet<Video> topten = new TreeSet<>(new ComparadorVideos());
		// Recorremos los v�deos de la colecci�n
		for(Video video: catalogoVideos.getVideos()) {
			// Si la lista tiene alg�n v�deo
			if(topten.size() != 0) {
				// Pero tiene menos de diez elementos
				if(topten.size() < 10) {
					// A�adimos el v�deo actual directamente
					topten.add(video);
				} else { // Si tiene ya 10 v�deos
					// A�adimos el v�deo actual
					topten.add(video);
					// Y eliminamos el que tenga el valor m�s bajo de reproducciones
					topten.remove(topten.last());
				}
			} else
				// En el caso de que la lista est� vac�a tambi�n a�adimos el video
				topten.add(video);
		}
		
		LinkedList<Integer> lista = new LinkedList<Integer>();
		for (Video video : topten)
			lista.addLast(video.getCodigo());
		
		return lista;
	}
	
	/*
	 * Solicitar el PDF con las listas del usuario, y guardarlo en la ruta pasada en
	 * el par�metro ruta
	 */
	public void solicitarPDF(String ruta) {
		this.usuarioActual.generarPDf(ruta);
	}

	/*
	 * Utilizar el componente Cargador de v�deos para a�adir al sistema los v�deos
	 * del archivo XML que se encuentra en la ruta pasada como argumento
	 */
	public void abrirXML(String ruta) {
		buscadorVideos.setArchivoVideos(ruta);
	}
	
	/*
	 * Obtiene los nombres de las ListaVideos del usuario actual
	 */
	public String[] obtenerListas() {
		return usuarioActual.getNombresListas().toArray(new String[] {});
	}
	
	/*
	 * Obtiene los nombres de los filtros que hay en el sistema
	 */
	public String[] obtenerFiltros() {
		return filtros.keySet().toArray(new String[] {});
	}
	
	/*
	 * Selecciona un filtro entre los que tiene el sistema y se lo asigna al usuario actual
	 */
	public void seleccionarFiltro(String filtro) {
		usuarioActual.setFiltro(filtros.get(filtro));
	}
	
	public String getFiltroUsuario() {
		return filtros.inverseBidiMap().get(usuarioActual.getFiltro());
	}
	
	public String getTituloVideo(int codigo) {
		return catalogoVideos.getVideo(codigo).getTitulo();
	}
	
	public String getUrlVideo(int codigo) {
		return catalogoVideos.getVideo(codigo).getUrl();
	}
	
	
	// Funciones de la ventana Nueva Lista
	
		/*
		 * Busca la lista que tenga el t�tulo/nombre introducido y devolverla. Si no se
		 * encuentra ninguna devolver null.
		 */
		public HashMap<String, String> realizarBusquedaLista(String nombre) {
			HashMap<String, String> videos = new HashMap<String, String>();
			listaActual = usuarioActual.getListaVideos(nombre);
			if (listaActual != null) {
				listaAnterior = new ListaVideos(listaActual);
				for (Video video : listaActual.getVideos()){
					videos.put(String.valueOf(video.getCodigo()), video.getUrl());
				}
				return videos;
			}
			return null;
		}
		
		/*
		 * Crear una lista con el nombre introducido
		 */
		public void crearLista(String nombre) {
			listaActual = usuarioActual.crearListaRepr(nombre);
		}
		
		/*
		 * Elimina la lista del sistema.
		 */
		public void eliminarLista() {
			if (listaActual != null)
				eliminarLista = true;
		}
		
		/*
		 * A�adir el v�deo con la url pasada como argumento a la lista que se est� editando
		 */
		public boolean a�adirVideoLista(int codigo) {
			if (listaActual != null)
				return listaActual.anadirVideo(catalogoVideos.getVideo(codigo));
			return false;
		}
		
		public void eliminarVideoLista(int codigo) {
			if (listaActual != null)
				listaActual.eliminarVideo(catalogoVideos.getVideo(codigo));
		}

		/*
		 * Reemplazar la lista anterior por esta, editada por el usuario.
		 */
		public void guardarCambios() {
			if ((listaActual != null) && (eliminarLista)) {
				usuarioActual.borrarLista(listaActual.getNombreLista());
				// Aqu� borramos la lista de la base de datos porque hacerlo luego complicar�a
				// en gran medida la implementaci�n, y es una operaci�n que tampoco supondr�
				// un gran problema de rendimiento
				adaptadorListaVideos.borrarListaVideos(listaActual);
				eliminarLista = false;
			}
			listaActual = null;
			listaAnterior = null;
		}
		
		public void deshacerCambios() {
			// Si listaAnterior es null significa que la lista creada es nueva, por lo que hay
			// que eliminarla del usuario actual
			if (listaAnterior == null)
				usuarioActual.eliminarLista(listaActual.getNombreLista());
			// Si listaAnterior tiene una lista es que la lista no ha sido creada, sino modificada,
			// por lo que tendremos que reemplazar la lista que el usuario ha estado modificando con la anterior
			else
				usuarioActual.reemplazarLista(listaAnterior);
		}

	// FIN funciones de la ventana Nueva Lista
		
		
	/*
	 * Funci�n auxiliar que busca los v�deos que tengan en el t�tulo las palabras pasadas en el par�metro
	 * "titulo", que tenga las etiquetas pasadas en el par�metro "etiquetas" y cumpla el filtro del usuario
	 */
	private List<Video> getVideos(String titulo, String[] etiquetas){
		// Primero obtiene los v�deos que tienen en su t�tulo la cadena pasada como par�metro y que tiene
		// las etiquetas que se le proporcionan
		// Se crea la lista que contendr� los v�deos
		LinkedList<Video> videos = new LinkedList<>();
		// Vamos recorriendo los v�deos del cat�logo
		for(Video video: catalogoVideos.getVideos()) {
			// Si el v�deo tiene en su t�tulo alguna cadena de las que se han pasado como par�metro
			if (containsIgnoreCase(video.getTitulo(), titulo)) {
				if (etiquetas != null) {
					int i;
					// Y tiene todas las etiquetas
					for (i = 0; i < etiquetas.length; i++)
						if(!video.containsEtiq(catalogoEtiquetas.getEtiqueta(etiquetas[i])))
							i = etiquetas.length + 1;
					// Se a�ade a la lista
					if (i == etiquetas.length)
						videos.add(video);
				} else
					videos.add(video);
			}
		}
		
		return usuarioActual.ejecutarFiltro(videos);
	}
	
	private boolean containsIgnoreCase(String cadena, String subcadena) {
		return cadena.toLowerCase().contains(subcadena.toLowerCase());
	}
}
