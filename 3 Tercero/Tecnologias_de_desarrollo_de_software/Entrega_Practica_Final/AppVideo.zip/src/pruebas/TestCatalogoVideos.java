package pruebas;

import static org.junit.Assert.*;


import org.junit.Test;

import controlador.ControladorAppVideo;
import modelo.CatalogoVideos;
import modelo.Video;
import persistencia.AdaptadorVideoTDS;

public class TestCatalogoVideos {

	ControladorAppVideo controlador = ControladorAppVideo.getUnicaInstancia();
	CatalogoVideos catalogo = CatalogoVideos.getUnicaInstancia();
		
	
	@Test
	public void testEliminarVideo() {
		Video video = catalogo.getVideo("https://www.youtube.com/watch?v=ZO0UtUbm1-o");
		if(video != null) {
			AdaptadorVideoTDS.getUnicaInstancia().borrarVideo(video);
			catalogo.eliminarVideo(video.getCodigo());
		}
	
	
		controlador.abrirXML("./xml/videos2.xml");
		AdaptadorVideoTDS.getUnicaInstancia().borrarVideo(catalogo.getVideo("https://www.youtube.com/watch?v=ZO0UtUbm1-o"));
		catalogo.eliminarVideo(catalogo.getVideo("https://www.youtube.com/watch?v=ZO0UtUbm1-o").getCodigo());
		
		Video video2 = catalogo.getVideo("https://www.youtube.com/watch?v=ZO0UtUbm1-o");
		assertEquals(null, video2);
		
	}


}
