package pruebas;

import static org.junit.Assert.*;

import java.util.Calendar;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;

import org.hamcrest.CoreMatchers;

import org.junit.Test;

import com.toedter.calendar.JDateChooser;

import controlador.ControladorAppVideo;
import modelo.CatalogoEtiquetas;
import modelo.CatalogoUsuarios;
import modelo.CatalogoVideos;
import modelo.Etiqueta;
import modelo.Usuario;
import modelo.Video;
import persistencia.AdaptadorVideoTDS;

public class TestControlador {

	ControladorAppVideo controlador = ControladorAppVideo.getUnicaInstancia();
		
	
	@Test
	public void testEnteradoCambioArchivo() {
		Video video = CatalogoVideos.getUnicaInstancia().getVideo("https://www.youtube.com/watch?v=ZO0UtUbm1-o");
		if(video != null) {
			AdaptadorVideoTDS.getUnicaInstancia().borrarVideo(video);
			CatalogoVideos.getUnicaInstancia().eliminarVideo(video.getCodigo());
		}
		
		int numEsperado = CatalogoVideos.getUnicaInstancia().getVideos().size() + 1;
		controlador.abrirXML("./xml/videos.xml");
		controlador.abrirXML("./xml/videos2.xml");
		assertEquals(numEsperado, CatalogoVideos.getUnicaInstancia().getVideos().size());
		Video nuevoVideo = CatalogoVideos.getUnicaInstancia().getVideo("https://www.youtube.com/watch?v=ZO0UtUbm1-o");
		
		if(nuevoVideo == null) fail("Video no insertado");
		
		assertEquals("CTR", nuevoVideo.getTitulo());
	}

	@Test
	public void testLoginUsuario() {
	
		char[] pass = new char[1];
		pass[0] = 'b';
		Usuario usuario = CatalogoUsuarios.getUnicaInstacia().getUsuario("b");
		if(usuario == null) {
			controlador.registrarUsuario("b", "b", Calendar.getInstance(), "b", "b", pass);
		}
		boolean actual = controlador.loginUsuario("b", pass);
		assertEquals(true, actual);
	}

	@Test
	public void testA�adirVideoARecientes() {
		char[] pass = new char[1];
		pass[0] = 'b';
		Usuario usuario = CatalogoUsuarios.getUnicaInstacia().getUsuario("b");
		if(usuario == null) {
			controlador.registrarUsuario("b", "b", Calendar.getInstance(), "b", "b", pass);
		}
		controlador.loginUsuario("b", pass);
		
		Video video = CatalogoVideos.getUnicaInstancia().getVideo("https://www.youtube.com/watch?v=ZO0UtUbm1-o");
		controlador.a�adirVideoARecientes(video.getCodigo());
		
		assertThat(CatalogoUsuarios.getUnicaInstacia().getUsuario("b").getRecientes(), CoreMatchers.hasItems(video));
		
	}
	
	@Test
	public void testTopTen() {
		controlador.abrirXML("./xml/videos.xml");
		controlador.abrirXML("./xml/videos2.xml");
		int numMayor = 0;
		for(Video video: CatalogoVideos.getUnicaInstancia().getVideos()) {
			if(video.getNumReproducciones() > numMayor) numMayor = video.getNumReproducciones();
		}
		Video video1 = CatalogoVideos.getUnicaInstancia().getVideo("https://www.youtube.com/watch?v=CI5bdVB2-Ic");
		video1.setNumReproducciones(numMayor+1);
		
		
		Video video2 = CatalogoVideos.getUnicaInstancia().getVideo("https://www.youtube.com/watch?v=X6pbDZPMMrA");
		video2.setNumReproducciones(numMayor+2);
		
		
		Video video3 = CatalogoVideos.getUnicaInstancia().getVideo("https://www.youtube.com/watch?v=gZxZvY8eJ8w");
		video3.setNumReproducciones(numMayor+3);
		
		Video video4 = CatalogoVideos.getUnicaInstancia().getVideo("https://www.youtube.com/watch?v=tf-KsrCkNGQ");
		video4.setNumReproducciones(numMayor+4);
	
		
		Video video5 = CatalogoVideos.getUnicaInstancia().getVideo("https://www.youtube.com/watch?v=MkGuLzQ4QNo");
		video5.setNumReproducciones(numMayor+5);
		
		
		Video video6 = CatalogoVideos.getUnicaInstancia().getVideo("https://www.youtube.com/watch?v=kzB4MrXWoO0");
		video6.setNumReproducciones(numMayor+6);
		
		
		Video video7 = CatalogoVideos.getUnicaInstancia().getVideo("https://www.youtube.com/watch?v=kp6caiKmO0E");
		video7.setNumReproducciones(numMayor+7);
		
		Video video8 = CatalogoVideos.getUnicaInstancia().getVideo("https://www.youtube.com/watch?v=PcdDtSndOqs");
		video8.setNumReproducciones(numMayor+8);
		
		Video video9 = CatalogoVideos.getUnicaInstancia().getVideo("https://www.youtube.com/watch?v=Gk5abdMIhrI");
		video9.setNumReproducciones(numMayor+9);
		
		
		
		
		Video video10 = CatalogoVideos.getUnicaInstancia().getVideo("https://www.youtube.com/watch?v=ZO0UtUbm1-o");
		video10.setNumReproducciones(numMayor+10);
		
		List<Video> videos = new LinkedList<>();
		for(Integer codigo: controlador.obtenerTopTen()) {
			videos.add(CatalogoVideos.getUnicaInstancia().getVideo(codigo));
		}
		
		
		assertThat(videos, CoreMatchers.hasItems(video1, video2, video3, video4, video5, video6, video7, video8, video9, video10));
	}
	
	@Test
	public void testBusqueda() {
		Usuario usuario;
		JDateChooser fecha_nacimiento = new JDateChooser();
		if(CatalogoUsuarios.getUnicaInstacia().getUsuario("a") == null) {
			usuario = new Usuario("a", "a", "a", "a", fecha_nacimiento.getCalendar(), "a");
			CatalogoUsuarios.getUnicaInstacia().addUsuario(usuario);
		}
		char [] pass = new char[1];
		pass[0] = 'a';
	
		controlador.loginUsuario("a", pass);
		
		controlador.abrirXML("./xml/videos.xml");
		controlador.abrirXML("./xml/videos2.xml");
		controlador.abrirXML("./xml/Supremo.xml");
		List<Video> videos = new LinkedList<>();
		Video video1 = CatalogoVideos.getUnicaInstancia().getVideo("https://www.youtube.com/watch?v=CI5bdVB2-Ic");//new Video("https://www.youtube.com/watch?v=ML9iv3i7qJ0", "Zeta-Super Mario Maker 2");
		Video video2 = CatalogoVideos.getUnicaInstancia().getVideo("https://www.youtube.com/watch?v=ZO0UtUbm1-o");//new Video("https://www.youtube.com/watch?v=ZO0UtUbm1-o", "CTR");
		videos.add(video1);
		videos.add(video2);
		Etiqueta etiqueta;
		if(CatalogoEtiquetas.getUnicaInstacia().getEtiqueta("Test") == null) {
			etiqueta = new Etiqueta("Test");
			CatalogoEtiquetas.getUnicaInstacia().addEtiqueta(etiqueta);
		} else { 
			etiqueta = CatalogoEtiquetas.getUnicaInstacia().getEtiqueta("Test");
			}
		if(!video1.containsEtiq(etiqueta)) video1.anadirEtiqueta(etiqueta);
		
		String[] etiquetas = new String[1];
		etiquetas[0] = etiqueta.getNombre();
		//Usuario usuario = new Usuario("", "", "", "", fecha.getCalendar(), "");
		HashMap<String,String> actual =  controlador.realizarBusqueda("", etiquetas); //usuario.busqueda(videos, etiquetas, "");
		assertThat(actual.keySet(), CoreMatchers.hasItems(String.valueOf(video1.getCodigo())));
	}

}
