package persistencia;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.StringTokenizer;

import beans.Entidad;
import beans.Propiedad;
import modelo.ListaVideos;
import modelo.Video;
import tds.driver.FactoriaServicioPersistencia;
import tds.driver.ServicioPersistencia;

public class AdaptadorListaVideosTDS implements IAdaptadorListaVideosDAO{

		private static ServicioPersistencia servicioPersistencia;
		private static AdaptadorListaVideosTDS unicaInstancia = null;
		
		private AdaptadorListaVideosTDS() {
			servicioPersistencia = FactoriaServicioPersistencia.getInstance().getServicioPersistencia();
		}
		
		public static AdaptadorListaVideosTDS getUnicaInstancia() {
			if(unicaInstancia == null) unicaInstancia = new AdaptadorListaVideosTDS();
			return unicaInstancia;
		}
		
		@Override
		public void registrarListaVideos(ListaVideos listaVideos) {
			Entidad eListaVideos = null;
			boolean existe = true;
			
			try {
				eListaVideos = servicioPersistencia.recuperarEntidad(listaVideos.getCodigo());
			} catch (NullPointerException e) {
				existe = false;
			}
			
			// Si la ListaVideos ya se encuentra en la base de datos no la registra
			if (existe)
				return;
			
			//Regitramos primero los videos
			AdaptadorVideoTDS adaptadorVideoTDS = AdaptadorVideoTDS.getUnicaInstancia();
			for(Video video: listaVideos.getVideos()) {
				adaptadorVideoTDS.registrarVideo(video);
			}
			
			// Creamos la entidad y asignamos sus atribuos
			eListaVideos = new Entidad();
			eListaVideos.setNombre("listavideos");
			eListaVideos.setPropiedades(new ArrayList<>(Arrays.asList(
					new Propiedad("nombreLista", listaVideos.getNombreLista()),
					new Propiedad("numVideos", String.valueOf(listaVideos.getNumVideos())),
					new Propiedad("videos", obtenerCodigosVideos(listaVideos.getVideos())))));
			
			// La registramos en la BBDD y nos quedamos con la entidad resultante
			Entidad nueva = servicioPersistencia.registrarEntidad(eListaVideos);
			
			// De esta obtenemos el c�digo (Id) y modificamos la ListaVideos que ten�amos anteriormente
			listaVideos.setCodigo(nueva.getId());
		}
		
		@Override
		public void borrarListaVideos(ListaVideos listaVideos) {
			Entidad eListaVideos = servicioPersistencia.recuperarEntidad(listaVideos.getCodigo());
			servicioPersistencia.borrarEntidad(eListaVideos);
		}
		
		@Override
		public void modificarListaVideos(ListaVideos listaVideos) {
			Entidad eListaVideos;
			
			eListaVideos = servicioPersistencia.recuperarEntidad(listaVideos.getCodigo());
			
			servicioPersistencia.eliminarPropiedadEntidad(eListaVideos, "nombreLista");
			servicioPersistencia.anadirPropiedadEntidad(eListaVideos, "nombreLista", listaVideos.getNombreLista());
			servicioPersistencia.eliminarPropiedadEntidad(eListaVideos, "numVideos");
			servicioPersistencia.anadirPropiedadEntidad(eListaVideos, "numVideos", String.valueOf(listaVideos.getNumVideos()));
			servicioPersistencia.eliminarPropiedadEntidad(eListaVideos, "videos");
			servicioPersistencia.anadirPropiedadEntidad(eListaVideos, "videos", obtenerCodigosVideos(listaVideos.getVideos()));
		}
		
		@Override
		public ListaVideos recuperarListaVideos(int codigo) {
			Entidad eListaVideos = servicioPersistencia.recuperarEntidad(codigo);
			
			String nombreLista = servicioPersistencia.recuperarPropiedadEntidad(eListaVideos, "nombreLista");
			int numVideos = Integer.parseInt(servicioPersistencia.recuperarPropiedadEntidad(eListaVideos, "numVideos"));
			List<Video> videos = obtenerVideosDesdeCodigos(servicioPersistencia.recuperarPropiedadEntidad(eListaVideos, "videos"));
			
			ListaVideos listaVideos = new ListaVideos(nombreLista);
			listaVideos.setVideos(videos);
			listaVideos.setNumVideos(numVideos);
			listaVideos.setCodigo(codigo);
			
			return listaVideos;
		}
		
		
		@Override
		public List<ListaVideos> recuperarTodosListaVideos() {
			List<Entidad> listaEntidades = servicioPersistencia.recuperarEntidades("listavideos");
			
			List<ListaVideos> listaListaVideos = new LinkedList<>();
			for(Entidad entidad : listaEntidades) {
				listaListaVideos.add(recuperarListaVideos(entidad.getId()));
			}
			
			return listaListaVideos;
		}
		
		
		// Funciones auxiliares
		
		private String obtenerCodigosVideos(List<Video> videos) {
			
			LinkedList<Video> listaVideos = (LinkedList<Video>) videos;
			
			String aux = "";
			for(Video video : listaVideos) {
				aux += video.getCodigo() + " ";
			}
			
			return aux.trim();
		}
		
		private List<Video> obtenerVideosDesdeCodigos(String videos){
			List<Video> listaVideos = new LinkedList<>();
			StringTokenizer stringTokenizer = new StringTokenizer(videos, " ");
			AdaptadorVideoTDS adaptadorVideoTDS = AdaptadorVideoTDS.getUnicaInstancia();
			while(stringTokenizer.hasMoreTokens()) {
				listaVideos.add(adaptadorVideoTDS.recuperarVideo(Integer.parseInt((String) stringTokenizer.nextElement())));
			}
			return listaVideos;
		}
}
