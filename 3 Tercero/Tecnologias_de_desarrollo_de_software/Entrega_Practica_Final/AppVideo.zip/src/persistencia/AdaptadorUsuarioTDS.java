package persistencia;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collection;
import java.util.LinkedList;
import java.util.List;
import java.util.StringTokenizer;

import beans.Entidad;
import beans.Propiedad;
import modelo.ListaVideos;
import modelo.Usuario;
import modelo.Video;
import tds.driver.FactoriaServicioPersistencia;
import tds.driver.ServicioPersistencia;

public class AdaptadorUsuarioTDS implements IAdapatadorUsuarioDAO{

	private static ServicioPersistencia servicioPersistencia;
	private static AdaptadorUsuarioTDS unicaInstancia;
	
	private AdaptadorUsuarioTDS() {
		servicioPersistencia = FactoriaServicioPersistencia.getInstance().getServicioPersistencia();
	}
	
	public static AdaptadorUsuarioTDS getUnicaInstancia() {
		if(unicaInstancia == null) unicaInstancia = new AdaptadorUsuarioTDS();
		return unicaInstancia;
	}
	
	@Override
	public void registrarUsuario(Usuario usuario) {
		Entidad eUsuario = null;
		boolean existe = true;
		
		try {
			eUsuario = servicioPersistencia.recuperarEntidad(usuario.getCodigo());
		} catch (NullPointerException e) {
			existe = false;
		}
		
		if (existe)
			return;
		
		//Regitramos primero los videos
		AdaptadorVideoTDS adaptadorVideoTDS = AdaptadorVideoTDS.getUnicaInstancia();
		for(Video video: usuario.getRecientes()) {
			adaptadorVideoTDS.registrarVideo(video);
		}
		
		//Registramos tambi�n las Listas de Videos
		AdaptadorListaVideosTDS adaptadorListaVideosTDS = AdaptadorListaVideosTDS.getUnicaInstancia();
		for(ListaVideos listaVideos: usuario.getListas()) {
			adaptadorListaVideosTDS.registrarListaVideos(listaVideos);
		}
		
		//Crear entidad Usuario
		eUsuario = new Entidad();
		eUsuario.setNombre("usuario");
		eUsuario.setPropiedades(new ArrayList<>(Arrays.asList(
				new Propiedad("premium", Boolean.toString(usuario.getPremium())),
				new Propiedad("login", usuario.getLogin()),
				new Propiedad("password", usuario.getPassword()),
				new Propiedad("nombre", usuario.getNombre()),
				new Propiedad("apellidos", usuario.getApellidos()),
				new Propiedad("email", usuario.getEmail()),
				new Propiedad("recientes", obtenerCodigosDesdeVideos(usuario.getRecientes())),
				new Propiedad("listas", obtenerCodigosDesdeListaVideos(usuario.getListas())),
				new Propiedad("fechaNac", String.valueOf(usuario.getFechaNac().getTimeInMillis())),
				new Propiedad("filtro", usuario.getFiltro()))));
		
		//Registrar entidad
		Entidad nueva = servicioPersistencia.registrarEntidad(eUsuario);
		
		//Asignar ID
		usuario.setCodigo(nueva.getId());
	}
	
	@Override
	public void borrarUsuario(Usuario usuario) {
		Entidad eUsuario = servicioPersistencia.recuperarEntidad(usuario.getCodigo());
		servicioPersistencia.borrarEntidad(eUsuario);
		
	}
	
	@Override
	public void modificarUsuario(Usuario usuario) {
		Entidad eUsuario;
		
		eUsuario = servicioPersistencia.recuperarEntidad(usuario.getCodigo());
		
		servicioPersistencia.eliminarPropiedadEntidad(eUsuario, "premium");
		servicioPersistencia.anadirPropiedadEntidad(eUsuario, "premium", Boolean.toString(usuario.getPremium()));
		servicioPersistencia.eliminarPropiedadEntidad(eUsuario, "login");
		servicioPersistencia.anadirPropiedadEntidad(eUsuario, "login", usuario.getLogin());
		servicioPersistencia.eliminarPropiedadEntidad(eUsuario, "password");
		servicioPersistencia.anadirPropiedadEntidad(eUsuario, "password", usuario.getPassword());
		servicioPersistencia.eliminarPropiedadEntidad(eUsuario, "nombre");
		servicioPersistencia.anadirPropiedadEntidad(eUsuario, "nombre", usuario.getNombre());
		servicioPersistencia.eliminarPropiedadEntidad(eUsuario, "apellidos");
		servicioPersistencia.anadirPropiedadEntidad(eUsuario, "apellidos", usuario.getApellidos());
		servicioPersistencia.eliminarPropiedadEntidad(eUsuario, "email");
		servicioPersistencia.anadirPropiedadEntidad(eUsuario, "email", usuario.getEmail());
		servicioPersistencia.eliminarPropiedadEntidad(eUsuario, "recientes");
		servicioPersistencia.anadirPropiedadEntidad(eUsuario, "recientes", obtenerCodigosDesdeVideos(usuario.getRecientes()));
		servicioPersistencia.eliminarPropiedadEntidad(eUsuario, "listas");
		servicioPersistencia.anadirPropiedadEntidad(eUsuario, "listas", obtenerCodigosDesdeListaVideos(usuario.getListas()));
		servicioPersistencia.eliminarPropiedadEntidad(eUsuario, "fechaNac");
		servicioPersistencia.anadirPropiedadEntidad(eUsuario, "fechaNac", String.valueOf(usuario.getFechaNac().getTimeInMillis()));
		servicioPersistencia.eliminarPropiedadEntidad(eUsuario, "filtro");
		servicioPersistencia.anadirPropiedadEntidad(eUsuario, "filtro", usuario.getFiltro());
		
	}
	
	@Override
	public Usuario recuperarUsuario(int codigo) {
		Entidad eUsuario = servicioPersistencia.recuperarEntidad(codigo);
		
		boolean premium = Boolean.valueOf(servicioPersistencia.recuperarPropiedadEntidad(eUsuario, "premium"));
		String login = servicioPersistencia.recuperarPropiedadEntidad(eUsuario, "login");
		String password = servicioPersistencia.recuperarPropiedadEntidad(eUsuario, "password");
		String nombre = servicioPersistencia.recuperarPropiedadEntidad(eUsuario, "nombre");
		String apellidos = servicioPersistencia.recuperarPropiedadEntidad(eUsuario, "apellidos");
		String email = servicioPersistencia.recuperarPropiedadEntidad(eUsuario, "email");
		String filtro = servicioPersistencia.recuperarPropiedadEntidad(eUsuario, "filtro");
		List<Video> recientes = obtenerVideosDesdeCodigos(servicioPersistencia.recuperarPropiedadEntidad(eUsuario, "recientes"));
		List<ListaVideos> listas = obtenerListaVideosDesdeCodigos(servicioPersistencia.recuperarPropiedadEntidad(eUsuario, "listas"));
		Calendar fechaNac = Calendar.getInstance();
		fechaNac.setTimeInMillis(Long.parseLong(servicioPersistencia.recuperarPropiedadEntidad(eUsuario, "fechaNac")));
		Usuario usuario = new Usuario(login, password, nombre, apellidos, fechaNac, email);
		usuario.setPremium(premium);
		usuario.setRecientes(recientes);
		usuario.setListas(listas);
		usuario.setCodigo(eUsuario.getId());
		usuario.setFiltro(filtro);
		
		return usuario;
	}
	
	@Override
	public List<Usuario> recuperarTodosUsuarios() {
		List<Entidad> entidades = servicioPersistencia.recuperarEntidades("usuario");
		
		List<Usuario> usuarios = new LinkedList<>();
		for(Entidad entidad: entidades) {
			usuarios.add(recuperarUsuario(entidad.getId()));
		}
		
		return usuarios;
	}
	
	private String obtenerCodigosDesdeVideos(List<Video> videos) {
		String aux = "";
		for(Video video: videos) {
			aux += video.getCodigo() + " ";
		}
		
		return aux.trim();
	}
	
	private List<Video> obtenerVideosDesdeCodigos(String videos) {
		List<Video> listaVideos = new LinkedList<>();
		StringTokenizer stringTokenizer = new StringTokenizer(videos, " ");
		AdaptadorVideoTDS adaptadorVideoTDS = AdaptadorVideoTDS.getUnicaInstancia();
		while(stringTokenizer.hasMoreTokens()) {
			listaVideos.add(adaptadorVideoTDS.recuperarVideo(Integer.parseInt((String)stringTokenizer.nextElement())));
		}
		return listaVideos;
	}
	
	private String obtenerCodigosDesdeListaVideos(Collection<ListaVideos> listaVideos) {
		String aux = "";
		for(ListaVideos listaVideo: listaVideos) {
			aux += listaVideo.getCodigo() + " ";
		}
		return aux.trim();
	}
	
	private List<ListaVideos> obtenerListaVideosDesdeCodigos(String listaVideos) {
		List<ListaVideos> listaListaVideos = new LinkedList<>();
		StringTokenizer stringTokenizer = new StringTokenizer(listaVideos, " ");
		AdaptadorListaVideosTDS adaptadorListaVideosTDS = AdaptadorListaVideosTDS.getUnicaInstancia();
		while(stringTokenizer.hasMoreTokens()) {
			listaListaVideos.add(adaptadorListaVideosTDS.recuperarListaVideos(Integer.parseInt((String)stringTokenizer.nextElement())));
		}
		return listaListaVideos;
	}
}
