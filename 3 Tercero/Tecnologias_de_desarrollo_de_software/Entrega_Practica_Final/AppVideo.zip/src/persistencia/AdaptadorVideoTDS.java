package persistencia;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.StringTokenizer;

import beans.Entidad;
import beans.Propiedad;
import modelo.CatalogoEtiquetas;
import modelo.Etiqueta;
import modelo.Video;
import tds.driver.FactoriaServicioPersistencia;
import tds.driver.ServicioPersistencia;

public class AdaptadorVideoTDS implements IAdaptadorVideoDAO{

	private static ServicioPersistencia servPersistencia;
	private static AdaptadorVideoTDS unicaInstancia = null;
	private static CatalogoEtiquetas catalogoEtiquetas;
	
	public static AdaptadorVideoTDS getUnicaInstancia() {
		
		if(unicaInstancia == null) unicaInstancia = new AdaptadorVideoTDS();
		return unicaInstancia;
	}
	
	private AdaptadorVideoTDS() {
		servPersistencia = FactoriaServicioPersistencia.getInstance().getServicioPersistencia();
		catalogoEtiquetas = CatalogoEtiquetas.getUnicaInstacia();
	}
	
	@Override
	public void registrarVideo(Video video) {
		Entidad eVideo = null;
		boolean existe = true;
		try {
			eVideo = servPersistencia.recuperarEntidad(video.getCodigo());
		} catch (NullPointerException e) {
			existe = false;
		}
		if(existe) return;
		
		// Crear entidad Video
		eVideo = new Entidad();
		eVideo.setNombre("video");
		eVideo.setPropiedades(new ArrayList<>(Arrays.asList(new Propiedad("titulo", video.getTitulo()), new Propiedad("url", video.getUrl()), new Propiedad("numReproducciones", String.valueOf(video.getNumReproducciones())), new Propiedad("etiquetas", obtenerCadenaEtiquetas(video.getEtiquetas())))));
		
		// Registrar entidad
		Entidad nueva = servPersistencia.registrarEntidad(eVideo);
		// Asignar ID
		video.setCodigo(nueva.getId());
	}
	
	@Override
	public void borrarVideo(Video video) {
		Entidad eVideo = servPersistencia.recuperarEntidad(video.getCodigo());
		servPersistencia.borrarEntidad(eVideo);
	}
	
	@Override
	public Video recuperarVideo(int codigo) {
		Entidad eVideo = servPersistencia.recuperarEntidad(codigo);
		
		String url = servPersistencia.recuperarPropiedadEntidad(eVideo, "url");
		String titulo = servPersistencia.recuperarPropiedadEntidad(eVideo, "titulo");
		int numReproducciones = Integer.parseInt(servPersistencia.recuperarPropiedadEntidad(eVideo, "numReproducciones"));
		List<Etiqueta> etiquetas = obtenerEtiquetasDesdeCadena(servPersistencia.recuperarPropiedadEntidad(eVideo, "etiquetas"));
		
		Video video = new Video(url, titulo);
		video.setNumReproducciones(numReproducciones);
		video.setCodigo(codigo);
		video.setEtiquetas(etiquetas);
		
		return video;
	}
	
	@Override
	public List<Video> recuperarTodosVideos() {
		List<Video> videos = new LinkedList<>();
		List<Entidad> entidades = servPersistencia.recuperarEntidades("video");
		for(Entidad entidad : entidades) {
			videos.add(recuperarVideo(entidad.getId()));
		}
		return videos;
	}
	
	@Override
	public void modificarVideo(Video video) {
		Entidad eVideo = servPersistencia.recuperarEntidad(video.getCodigo());
		
		servPersistencia.eliminarPropiedadEntidad(eVideo, "url");
		servPersistencia.anadirPropiedadEntidad(eVideo, "url", video.getUrl());
		servPersistencia.eliminarPropiedadEntidad(eVideo, "titulo");
		servPersistencia.anadirPropiedadEntidad(eVideo, "titulo", video.getTitulo());
		servPersistencia.eliminarPropiedadEntidad(eVideo, "numReproducciones");
		servPersistencia.anadirPropiedadEntidad(eVideo, "numReproducciones", String.valueOf(video.getNumReproducciones()));
		servPersistencia.eliminarPropiedadEntidad(eVideo, "etiquetas");
		servPersistencia.anadirPropiedadEntidad(eVideo, "etiquetas", obtenerCadenaEtiquetas(video.getEtiquetas()));
	}
	
	
	// Funciones auxiliares
	
	/*
	 * Obtiene un String con las etiquetas del v�deo para poder guardarlas en la base de datos
	 */
	private String obtenerCadenaEtiquetas(List<Etiqueta> etiquetas) {
		String aux = "";
		for(Etiqueta etiqueta : etiquetas) {
			aux += etiqueta.getNombre() + "*";
		}
		
		return aux.trim();
	}
	
	private List<Etiqueta> obtenerEtiquetasDesdeCadena(String etiquetas){
		List<Etiqueta> listaEtiquetas = new LinkedList<>();
		StringTokenizer stringTokenizer = new StringTokenizer(etiquetas, "*");
		while(stringTokenizer.hasMoreTokens()) {
			String nombreEtiqueta = (String) stringTokenizer.nextElement();
			// IMPORTANTE
			// Aqu� se referencia al cat�logo de etiquetas cuando no es una buena pr�ctica hacerlo. El problema
			// es que no se le puede pedir al controlador dicho cat�logo porque puede que en el momento de hacerlo
			// el controlador est� en proceso de creaci�n, es decir, estar�amos creando un bucle que no acabar�a:
			// El controlador se empieza a crear y ejecuta esta funci�n que a su vez le pide al controlador que se cree...
			// Por ello hemos decidido que se referencie al cat�logo.
			Etiqueta etiqueta = catalogoEtiquetas.getEtiqueta(nombreEtiqueta);
			// Si la etiqueta no existe se crea y se a�ade al cat�logo
			if(etiqueta == null) {
				etiqueta = new Etiqueta(nombreEtiqueta);
				catalogoEtiquetas.addEtiqueta(etiqueta);
			}
			listaEtiquetas.add(etiqueta); 
		}
		return listaEtiquetas;
	}
}
