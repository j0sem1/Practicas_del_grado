package modelo;

import java.util.Collection;

public class FiltroMisListas implements Filtro{

	/*
	 * El filtro no mostrar� los v�deos que ya est�n en alguna lista del usuario
	 */
	@Override
	public boolean filtrarVideo(Video video, Usuario usuario) {
		Collection<ListaVideos> listas = usuario.getListas();
		for(ListaVideos listaVideo: listas) {
			if(listaVideo.containsVideo(video.getCodigo())) return false;
		}
		return true;
	}
}
