package modelo;

import java.util.LinkedList;
import java.util.List;

public class ListaVideos {
	private int codigo;
	private String nombreLista;
	private int numVideos;
	private LinkedList<Video> videos;
	
	public ListaVideos(String nombreLista) {
		this.codigo = 0;
		this.nombreLista = nombreLista;
		this.numVideos = 0;
		this.videos = new LinkedList<Video>();
	}
	
	/*
	 * Constructor para crear una lista que sea una copia de otra que se pase como par�metro
	 */
	public ListaVideos(ListaVideos lista) {
		this.codigo = lista.getCodigo();
		this.nombreLista = lista.getNombreLista();
		this.numVideos = lista.getNumVideos();
		this.videos = new LinkedList<Video>(lista.getVideos());
	}
	
	public String getNombreLista() {
		return nombreLista;
	}
	
	public int getNumVideos() {
		return numVideos;
	}
	
	public List<Video> getVideos() {
		return this.videos;
	}
	
	public void setNombreLista(String nombreLista) {
		this.nombreLista = nombreLista;
	}
	
	public void setNumVideos(int numVideos) {
		this.numVideos = numVideos;
	}
	
	public void setVideos(List<Video> videos) {
		this.videos = new LinkedList<Video>(videos);
	}
	
	public int getCodigo() {
		return codigo;
	}
	
	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}
	
	public boolean anadirVideo(Video video) {
		if (!this.containsVideo(video.getCodigo())) {
			this.videos.addLast(video);
			this.numVideos++;
			return true;
		}
		return false;
	}
	
	public boolean containsVideo(Video video) {
		return videos.contains(video);
	}
	
	/*
	 * Comprueba si la lista tiene a�adido un v�deo con el c�digo pasado como
	 * par�metro
	 */
	public boolean containsVideo(int codigo) {
		for (Video video : videos)
			if (video.getCodigo() == codigo)
				return true;
		return false;
	}
	
	public void eliminarVideo(Video video) {
		int codigo = video.getCodigo();
		for (Video videoActual : videos)
			if (codigo == videoActual.getCodigo()) {
				videos.remove(videoActual);
				return;
			}
	}
}
