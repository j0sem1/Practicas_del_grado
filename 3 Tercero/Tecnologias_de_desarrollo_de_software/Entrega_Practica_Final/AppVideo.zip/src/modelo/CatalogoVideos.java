package modelo;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;


import persistencia.DAOException;
import persistencia.FactoriaDAO;
import persistencia.IAdaptadorVideoDAO;

public class CatalogoVideos {

	private HashMap<Integer, Video> videos;
	private static CatalogoVideos unicaInstacia;
	
	private FactoriaDAO factoriaDAO;
	private IAdaptadorVideoDAO adaptadorVideoDAO;
	
	private CatalogoVideos() {
		try {
			factoriaDAO = FactoriaDAO.getInstancia(FactoriaDAO.DAO_TDS);
			adaptadorVideoDAO = factoriaDAO.getVideoDAO();
			videos = new HashMap<>();
			this.cargarCatalogo();
		} catch (DAOException e) {
			e.printStackTrace();
		}
	}
	
	public static CatalogoVideos getUnicaInstancia() {
		if(unicaInstacia == null) unicaInstacia = new CatalogoVideos();
		return unicaInstacia;
	}
	
	public void addVideo(Video video) {
		this.videos.put(video.getCodigo(), video);
	}
	
	public List<Video> getVideos() {
		return new LinkedList<>(videos.values());
	}
	
	public Video getVideo(String url) {
		for(Video video: this.videos.values()) {
			if(video.getUrl().equals(url)) {
				return video;
			}
		}
		return null;
	}
	
	public Video getVideo(int codigo) {
		return this.videos.get(codigo);
	}
	
	/*
	 * Se cargan los v�deos de la base de datos en el cat�logo
	 */
	private void cargarCatalogo() {
		List<Video> videos = adaptadorVideoDAO.recuperarTodosVideos();
		for(Video video: videos) {
			this.videos.put(video.getCodigo(), video);
		}
	}
	
	public void eliminarVideo(int codigo) {
		this.videos.remove(codigo);
	}
}
