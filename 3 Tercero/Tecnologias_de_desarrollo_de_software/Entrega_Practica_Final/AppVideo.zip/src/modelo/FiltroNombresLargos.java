package modelo;

public class FiltroNombresLargos implements Filtro{

	/*
	 * Filtra los v�deos que tengan un t�tulo m�s largo que 15 caracteres
	 */
	@Override
	public boolean filtrarVideo(Video video, Usuario usuario) {
		if(video.getTitulo().length() > 16) return false;
		return true;
	}
}
