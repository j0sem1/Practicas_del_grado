package modelo;

public interface Filtro {
	
	/*
	 * M�todo a implementar por las subclases. Devolver� true si el v�deo
	 * cumple el filtro, y false en el caso contrario
	 */
	boolean filtrarVideo(Video video, Usuario usuario);
}
