package modelo;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;

import persistencia.DAOException;
import persistencia.FactoriaDAO;
import persistencia.IAdapatadorUsuarioDAO;

public class CatalogoUsuarios {

	private HashMap<String, Usuario> usuarios;
	private static CatalogoUsuarios unicaInstacia;
	private FactoriaDAO factoria;
	private IAdapatadorUsuarioDAO adapatadorUsuarioDAO;
	
	private CatalogoUsuarios() {
		try {
			factoria = FactoriaDAO.getInstancia(FactoriaDAO.DAO_TDS);
			adapatadorUsuarioDAO = factoria.getUsuarioDAO();
			this.usuarios = new HashMap<>();
			cargarCatalogo();
		} catch (DAOException e) {
			// Bloque catch generado autom�ticamente
			e.printStackTrace();
		}
	}
	
	/*
	 * Recupera todos los usuarios de la base de datos
	 */
	private void cargarCatalogo() {
		List<Usuario> usuarios = adapatadorUsuarioDAO.recuperarTodosUsuarios();
		for(Usuario usuario: usuarios) {
			this.usuarios.put(usuario.getLogin(), usuario);
		}
	}
	
	public static CatalogoUsuarios getUnicaInstacia() {
		if(unicaInstacia == null) unicaInstacia = new CatalogoUsuarios();
		return unicaInstacia;
	}
	
	// En el mapa la Key es el login del usuario, y el value el objeto Usuario
	public void addUsuario(Usuario usuario) {
		this.usuarios.put(usuario.getLogin(), usuario);
	}
	
	public List<Usuario> getUsuarios() {
		return new LinkedList<>(usuarios.values());
	}
	
	public Usuario getUsuario(int codigo) {
		for(Usuario usuario: this.usuarios.values()) {
			if(usuario.getCodigo() == codigo) return usuario;
		}
		return null;
	}
	
	public Usuario getUsuario(String login) {
		return this.usuarios.get(login);
	}
	
	public void modificarUsuario(Usuario newUsuario) {
		usuarios.replace(newUsuario.getLogin(), newUsuario);
	}
}
