package modelo;

import java.util.Comparator;

public class ComparadorVideos implements Comparator<Video>{

	@Override
	public int compare(Video arg0, Video arg1) {
		// Si el v�deo arg1 tiene m�s reproducciones que el v�deo arg0 se devuelve un entero >0, en el caso contrario
		// un entero <0. Si tienen el mismo n�mero de reproducciones se comparan las url alfab�ticamente
		int criterio1 = ((Integer) arg1.getNumReproducciones()).compareTo((Integer) arg0.getNumReproducciones());
		if(criterio1 == 0) return arg0.getUrl().compareTo(arg1.getUrl());
		return criterio1;
	}
}
