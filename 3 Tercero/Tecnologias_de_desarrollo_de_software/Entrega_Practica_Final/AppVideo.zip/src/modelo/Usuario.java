package modelo;

import java.io.FileOutputStream;
import java.util.Calendar;
import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;

import com.itextpdf.text.Document;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;

public class Usuario {
	private int codigo;
	private boolean premium;
	private String login;
	private String password;
	private String nombre;
	private String apellidos;
	private Calendar fechaNac;
	private String email;
	private LinkedList<Video> recientes;
	private HashMap<String, ListaVideos> listas;
	private Filtro filtro;
	
	public Usuario(String login, String password, String nombre, String apellidos, Calendar fechaNac, String email) {
		this.premium = false;
		this.login = login;
		this.password = password;
		this.nombre = nombre;
		this.apellidos = apellidos;
		this.fechaNac = fechaNac;
		this.email = email;
		this.recientes = new LinkedList<>();
		this.listas = new HashMap<>();
		this.filtro = new FiltroNoFiltro();
	}
	
	public Collection<ListaVideos> getListas() {
		return this.listas.values();
	}
	
	public List<String> getNombresListas(){
		return new LinkedList<String>(listas.keySet());
	}
	
	public List<Video> getRecientes() {
		return this.recientes;
	}
	
	public boolean getPremium() {
		return this.premium;
	}
	
	public String getLogin() {
		return login;
	}
	
	public int getCodigo() {
		return this.codigo;
	}
	
	public String getPassword() {
		return password;
	}
	
	public String getNombre() {
		return nombre;
	}
	
	public String getApellidos() {
		return apellidos;
	}
	
	public Calendar getFechaNac() {
		return fechaNac;
	}
	
	public String getEmail() {
		return email;
	}
	
	public boolean isPremium() {
		return premium;
	}
	
	public String getFiltro() {
		return filtro.getClass().getName();
	}
	
	public void setRecientes(List<Video> recientes) {
		if (recientes != null)
			this.recientes = (LinkedList<Video>) recientes;
	}
	
	public void setApellidos(String apellidos) {
		this.apellidos = apellidos;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	public void setFechaNac(Calendar fechaNac) {
		this.fechaNac = fechaNac;
	}
	
	public void setLogin(String login) {
		this.login = login;
	}
	
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	
	public void setPassword(String password) {
		this.password = password;
	}
	
	public void setPremium(boolean premium) {
		this.premium = premium;
	}
	
	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}
	
	/*
	 * Establece un nuevo mapa de ListaVideos
	 */
	public void setListas(List<ListaVideos> lista) {
		this.listas = new HashMap<>();
		for(ListaVideos elem: lista) {
			this.listas.put(elem.getNombreLista(), elem);
		}
	}
	
	/*
	 * Atribuye un nuevo filtro al usuario cre�ndolo
	 */
	public void setFiltro(String nombreClaseFiltro) {
		try {
			// obtengo una instancia de Class para esa clase
			@SuppressWarnings("unchecked")
			Class<Filtro> clase = (Class<Filtro>) Class.forName(nombreClaseFiltro);
			
			try {
				// obtengo la instancia a traves del ctor nulo
				filtro = (Filtro) clase.newInstance();
			} catch (InstantiationException | IllegalAccessException e) {
				// Auto-generated catch block
				e.printStackTrace();
			}
			
		} catch (ClassNotFoundException e1) {
			// Auto-generated catch block
			e1.printStackTrace();
		}
	}
	
	public Usuario anadirVidReciente(Video video) {
		// No se utiliza recientes.contains() porque da problemas
		if (videoInRecientes(video)) {
			// No se utiliza recientes.remove() porque da problemas
			eliminarVideoRecientes(video);
			recientes.addFirst(video);
		} else if (recientes.size() < 5) {	// Si el usuario tiene menos de 5 v�deos reproducidos
			recientes.addFirst(video);		// recientemente se a�ade directamente
		} else {							// En caso contrario se elimina el m�s antiguo y se a�ade
			recientes.removeLast();
			recientes.addFirst(video);
		}
		return this;
	}
	
	public boolean comprobarPassword(String password) {
		return this.password.equals(password);
	}
	
	public List<Video> ejecutarFiltro(List<Video> videos){
		// Se crea la lista que contendr� los v�deos
		LinkedList<Video> busqueda = new LinkedList<>();
		for (Video video : videos)
			if (filtro.filtrarVideo(video, this))
				busqueda.add(video);
		return busqueda;
	}
	
	public ListaVideos crearListaRepr(String nombre) {
		ListaVideos nueva = new ListaVideos(nombre);
		this.listas.put(nombre, nueva);
		return nueva;
	}
	
	/*
	 * Se a�ade el v�deo pasado como par�metro a la lista que tiene el usuario con el
	 * nombre pasado como par�metro
	 */
	public boolean anadirVideoList(Video video, String lista) {
		ListaVideos listaVideos;
		if((listaVideos = this.listas.get(lista)) == null) return false;
		listaVideos.anadirVideo(video);
		return true;
	}
	
	/*
	 * Genera el archivo pdf que contendr� las listas del usuario
	 */
	public void generarPDf(String ruta) {
		try {
			// Define un archivo de salida con la ruta indicada
			FileOutputStream archivo = new FileOutputStream(ruta + "\\MisListas.pdf");
			// Crea un nuevo documento de la clase com.itextpdf.text.Document
			Document documento = new Document();
			// Crea una instancia de la clase com.itextpdf.text.pdf.PdfWriter con el archivo a crear
			// y el documento creado
			PdfWriter.getInstance(documento, archivo);
			// Abre el documento y va a�adiendo las listas
			documento.open();
			documento.add(new Paragraph("Listas de V�deos"));
			documento.add(new Paragraph());
			for(ListaVideos listaVideos: this.listas.values()) {
				documento.add(new Paragraph());
				documento.add(new Paragraph("Nombre de la lista: "+listaVideos.getNombreLista()));
				documento.add(new Paragraph());
				documento.add(new Paragraph("V�deos:"));
				for(Video video: listaVideos.getVideos()) {
					documento.add(new Paragraph("      "+video.getTitulo()));
				}
			}
			// Finalmente lo cierra y ya est� disponible para el usuario
			documento.close();
		} catch (Exception e) {
			
			e.printStackTrace();
		}
	}
	
	/*
	 * Comprueba si es el cumplea�os del usuario
	 */
	public boolean isCumplea�os() {
		Calendar fechaActual = Calendar.getInstance();
		return ((fechaNac.get(Calendar.DAY_OF_MONTH) == fechaActual.get(Calendar.DAY_OF_MONTH)) && (fechaNac.get(Calendar.MONTH) == fechaActual.get(Calendar.MONTH)));
	}
	
	public ListaVideos getListaVideos(String nombre) {
		return this.listas.get(nombre);
	}
	
	public void borrarLista(String lista) {
		this.listas.remove(lista);
	}
	
	public void anadirLista(ListaVideos lista) {
		listas.put(lista.getNombreLista(), lista);
	}
	
	public void eliminarLista(String nombre) {
		listas.remove(nombre);
	}
	
	public void reemplazarLista(ListaVideos listaAnterior) {
		listas.replace(listaAnterior.getNombreLista(), listaAnterior);
	}
	
	/*
	 * Comprueba si el v�deo pasado como par�metro est� en la lista de recientes del usuario
	 */
	private boolean videoInRecientes(Video video) {
		String url = video.getUrl();
		for (Video videoActual : recientes)
			if (videoActual.getUrl().equals(url))
				return true;
		return false;
	}
	
	private void eliminarVideoRecientes(Video video) {
		String url = video.getUrl();
		for (int i = 0; i < recientes.size(); i++)
			if (recientes.get(i).getUrl().equals(url))
				recientes.remove(i);
	}
}