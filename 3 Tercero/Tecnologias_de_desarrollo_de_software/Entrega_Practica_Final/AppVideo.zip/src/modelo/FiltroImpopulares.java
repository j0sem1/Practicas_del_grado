package modelo;

public class FiltroImpopulares implements Filtro{

	/*
	 * El v�deo cumple el filtro si tiene 5 reproducciones o m�s
	 */
	@Override
	public boolean filtrarVideo(Video video, Usuario usuario) {
		if(video.getNumReproducciones() < 5) return false;
		return true;
	}
}
