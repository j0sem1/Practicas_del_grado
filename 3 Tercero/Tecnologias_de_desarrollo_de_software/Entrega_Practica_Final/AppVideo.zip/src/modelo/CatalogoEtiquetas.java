package modelo;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;

public class CatalogoEtiquetas {

	private HashMap<String, Etiqueta> etiquetas;
	private static CatalogoEtiquetas unicaInstacia;
	
	private CatalogoEtiquetas() {
		etiquetas = new HashMap<>();
	}
	
	public static CatalogoEtiquetas getUnicaInstacia() {
		if (unicaInstacia == null) unicaInstacia = new CatalogoEtiquetas();
		return unicaInstacia;
	}
	
	public void addEtiqueta(Etiqueta etiqueta) {
		etiquetas.put(etiqueta.getNombre(), etiqueta);
	}
	
	public List<Etiqueta> getEtiquetas() {
		return new LinkedList<>(etiquetas.values());
	}
	
	public Etiqueta getEtiqueta(String nombre) {
		return etiquetas.get(nombre);
	}
}
