package modelo;

import java.util.LinkedList;
import java.util.List;

public class Video {
	private int codigo;
	private String url;
	private String titulo;
	private int numReproducciones;
	private LinkedList<Etiqueta> etiquetas;
	
	public Video(String url, String titulo) {
		this.url = url;
		this.titulo = titulo;
		this.numReproducciones = 0;
		this.codigo = 0;
		this.etiquetas = new LinkedList<Etiqueta>();
	}
	
	public String getUrl() {
		return url;
	}
	
	public String getTitulo() {
		return titulo;
	}
	
	public int getNumReproducciones() {
		return numReproducciones;
	}
	
	public void setNumReproducciones(int numReproducciones) {
		this.numReproducciones = numReproducciones;
	}
	
	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}
	
	public void setUrl(String url) {
		this.url = url;
	}
	
	public int getCodigo() {
		return codigo;
	}
	
	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}
	
	public List<Etiqueta> getEtiquetas() {
		return new LinkedList<>(etiquetas);
	}
	
	public void setEtiquetas(List<Etiqueta> etiquetas) {
		// �Es correcto este casting?
		this.etiquetas = (LinkedList<Etiqueta>) etiquetas;
	}
	
	public Video anadirEtiqueta(Etiqueta etiqueta) {
		etiquetas.add(etiqueta);
		return this;
	}
	
	public boolean containsEtiq(Etiqueta etiqueta) {
		return etiquetas.contains(etiqueta);
	}
	
	public Video incrementarNumReproducc() {
		numReproducciones++;
		return this;
	}
}
