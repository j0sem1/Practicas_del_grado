package modelo;

public class FiltroNoFiltro implements Filtro{

	/*
	 * No aplica ning�n filtro
	 */
	@Override
	public boolean filtrarVideo(Video video, Usuario usuario) {
		return true;
	}
}
