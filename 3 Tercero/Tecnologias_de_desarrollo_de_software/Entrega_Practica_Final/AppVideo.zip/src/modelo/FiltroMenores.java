package modelo;

public class FiltroMenores implements Filtro{

	/*
	 * Si el v�deo tiene la etiqueta "Adultos" no pasar� el filtro
	 */
	@Override
	public boolean filtrarVideo(Video video, Usuario usuario) {
		Etiqueta adultos = new Etiqueta("Adultos");
		if(video.containsEtiq(adultos)) return false;
		return true;
	}
}
