package umu.tds.componentes;

import java.io.Serializable;
import java.util.LinkedList;
import java.util.List;

import umu.tds.videos.CargadorVideos;
import umu.tds.videos.Videos;

public class BuscadorVideosTDS implements IBuscadorVideos, Serializable{

	private String archivoVideos;
	private Videos listaVideos;
	private LinkedList<VideosListener> archivoListeners;
	
	public BuscadorVideosTDS() {
		this.archivoVideos = "";
		this.listaVideos = new Videos();
		this.archivoListeners = new LinkedList<>();
	}
	
	public String getArchivoVideos() {
		return archivoVideos;
	}
	
	public List<VideosListener> getArchivoListeners() {
		return (new LinkedList<>(this.archivoListeners));
	}
	
	public void setArchivoVideos(String archivoVideos) {
		
		if (this.archivoVideos != archivoVideos) {
			Videos newLista = CargadorVideos.cargarVideos(archivoVideos);
			VideosEvent evento = new VideosEvent(this, this.listaVideos, newLista);
			notificarCambio(evento);
		}
		this.archivoVideos = archivoVideos;
	}
	
	private void notificarCambio(VideosEvent event) {
		LinkedList<VideosListener> listaCopia = null;
		synchronized (this) {
			listaCopia = new LinkedList<>(this.archivoListeners);
		}
		
		for(VideosListener vl: listaCopia) {
			vl.enteradoCambioArchivo(event);
		}
		
	}
	
	public synchronized void addArchivoListener(VideosListener listener) {
		this.archivoListeners.add(listener);
	}
	
	public synchronized void removeArchivoListener(VideosListener listener) {
		this.archivoListeners.remove(listener);
	}
}
