package umu.tds.componentes;

import java.util.List;

public interface IBuscadorVideos {

	public String getArchivoVideos();
	public List<VideosListener> getArchivoListeners();
	public void setArchivoVideos(String archivoVideos);
	public void addArchivoListener(VideosListener listener);
	public void removeArchivoListener(VideosListener listener);
	
}
