package umu.tds.componentes;

import java.util.EventObject;

import umu.tds.videos.Videos;

public class VideosEvent extends EventObject{

	private static final long serialVersionUID = 1L;
	protected Videos oldLista, newLista;
	
	public VideosEvent(Object obj, Videos oldLista, Videos newLista) {
		super(obj);
		this.oldLista = oldLista;
		this.newLista = newLista;
	}
	
	public Videos getNewLista() {
		return newLista;
	}
	
	public Videos getOldLista() {
		return oldLista;
	}
}
