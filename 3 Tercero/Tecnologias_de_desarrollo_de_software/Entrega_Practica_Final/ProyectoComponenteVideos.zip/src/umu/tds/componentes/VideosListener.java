package umu.tds.componentes;

import java.util.EventListener;
import java.util.EventObject;

public interface VideosListener extends EventListener{

	public void enteradoCambioArchivo(EventObject e);
}
